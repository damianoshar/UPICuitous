#pragma once
#include <JuceHeader.h>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <utility>
#include "UpicModel.h"
#include "UpicEngine.h"
#include "ModelSnapshot.h"
#include "ScoreEditor.h"
#include "ScoreViewBar.h"
#include "Knob.h"
#include "ArcListPanel.h"
#include "MidiHub.h"
#include "WaveformEditor.h"
#include "EnvelopeEditor.h"
#include "LibraryManager.h"
#include "OverlayPanels.h"
#include "FreqTableEditor.h"
#include "AmpTableEditor.h"
#include "GroupPanel.h"
#include "SequencePanel.h"
#include "ChannelPanel.h"
#include "SampleExtractPanel.h"  // WP7
#include "UserLibrary.h"          // WP7
#include "OscScrubReceiver.h"
#include "JobRunner.h"
#include "UpicButtonIcons.h"

//==============================================================================
// WP7: the audio preview routes.
//
// The score's ordinary scrub/freeze routes and the sample-extraction A/B
// route are mutually exclusive. One atomic token is the arbiter: its low two
// bits name the route and its upper bits carry that route's generation (the
// extraction generation, or the ordinary route's reset serial). The audio
// thread reads the token once per block, so an old extraction snapshot can
// never be combined with a newly enabled scrub or freeze.
enum class AudioPreviewRoute : std::uint8_t
{
    none = 0,
    scrub,
    freeze,
    sampleExtract
};

constexpr std::uint64_t makeAudioPreviewRouteToken (AudioPreviewRoute route,
                                                    std::uint64_t generation) noexcept
{
    constexpr std::uint64_t generationMask = (std::uint64_t { 1 } << 62) - 1;
    return ((generation & generationMask) << 2)
         | static_cast<std::uint64_t> (route);
}

constexpr AudioPreviewRoute audioPreviewRouteFromToken (std::uint64_t token) noexcept
{
    return static_cast<AudioPreviewRoute> (token & std::uint64_t { 3 });
}

constexpr std::uint64_t audioPreviewGenerationFromToken (std::uint64_t token) noexcept
{
    return token >> 2;
}

//==============================================================================
// Main UPIC window: transport + score page + wavetable/envelope editors.
// X=time, Y=pitch(log). Each arc = wavetable osc * envelope * intensity.
//==============================================================================
class MainComponent : public juce::AudioAppComponent,
                      public juce::Timer,
                      private OscScrubReceiver::Listener
{
public:
    // pluginMode (v1.11): VST3 wrapper - the host drives prepareToPlay /
    // getNextAudioBlock instead of an audio device, and the Live-tab input tap
    // reads the host's input bus (see setPluginInputChannels).
    explicit MainComponent(bool pluginMode = false);
    ~MainComponent() override;

    void prepareToPlay(int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    // v1.33.4 (M21): the largest block a host may send. The score and freeze
    // buffers are preallocated for it, so the audio callback never grows
    // them (a malloc on the audio thread).
    static constexpr int kMaxAudioBlock = 8192;

    // v1.33.4 (M21): size the audio buffers on the message thread.
    void prepareAudioBuffers (int samplesPerBlockExpected);

    // v1.15: the score render for one block (into its own buffer, so the
    // caller can fade it when the block cannot be rendered).
    // v1.18 (wave 15): the render comes from the lock-free snapshot, so the
    // audio thread never takes dataLock any more.
    void renderScoreBlock(const ModelSnapshot& snap, float* left, float* right, int numSamples,
                          double sampleRate);

    // v1.30 (5.3 refactor): the parts of the audio block that were inlined
    // in getNextAudioBlock() are their own methods. They all run on the
    // audio thread, so they only touch the members.
    struct AudioBlock
    {
        float* outL = nullptr;      // the device / host buffer
        float* outR = nullptr;
        float* scoreL = nullptr;    // the rendered score
        float* scoreR = nullptr;
        float* freezeL = nullptr;   // the frozen (held) score
        float* freezeR = nullptr;
        float* extractL = nullptr;  // WP7: the extraction preview's own output
        float* extractR = nullptr;
        int numSamples = 0;
        bool playingAtStart = false;
        // v1.33.4 (L14): the sample rate, read once per block (it crosses
        // the thread boundary: the device writes it, the audio thread
        // reads it).
        double sr = 44100.0;
    };

    void mixMonitorInput (float* left, float* right, int numSamples);
    void applyScoreFade (float* scoreLeft, float* scoreRight, int numSamples,
                         int fadeSamples, bool rendered, bool modelChanged,
                         bool transportStarting);
    void mixMasterGain (float* left, float* right, const float* scoreLeft,
                        const float* scoreRight, int numSamples);
    // F1: one gain envelope for both transport edges (start and stop). It is
    // applied to the score, not the monitor input: stopping the transport
    // must not fade a live microphone.
    void applyTransportGain (float* scoreLeft, float* scoreRight, int numSamples,
                             double sampleRate, bool scoreAudible);
    void renderScrubPreview (const ModelSnapshot& snap, AudioBlock& block,
                             double previewGain, std::uint64_t routeGeneration);
    void renderScrubFreeze (const ModelSnapshot& snap, AudioBlock& block,
                            double freezeGain, std::uint64_t routeGeneration);

    // v1.15: call after a change that replaces the sound that is playing
    // (page change, loaded material, pitch-mode switch) - the audio thread
    // fades across it instead of cutting
    //
    // v1.33.4 (M22): it also bumps the model REVISION - the counter that
    // says "the model changed". The status timer used to deep-copy every
    // page, arc, waveform and envelope 30 times a second, even while
    // nothing changed; now it copies only when the revision moved.
    //
    // v1.33.4 (L15): it also marks the piece as "not saved". The app asks
    // before it closes when the piece differs from what was last written.
    // `affectsPiece` is false for the changes that are not part of the piece
    // (the loop toggle), so they do not make the app ask to save.
    void markModelChanged (bool affectsPiece = true)
    {
        modelEpoch.fetch_add(1, std::memory_order_relaxed);
        modelRevision.fetch_add(1, std::memory_order_relaxed);
        if (affectsPiece)
            pieceDirty.store (true, std::memory_order_relaxed);
    }

    // v1.33.4 (L15): the unsaved-changes flag. The standalone window asks
    // before it closes when the piece has unsaved changes (the review:
    // "application close directly calls quit() - an accidental closing needs
    // a recovery path").
    bool pieceHasUnsavedChanges() const { return pieceDirty.load (std::memory_order_relaxed); }
    void markPieceSaved() { pieceDirty.store (false, std::memory_order_relaxed); }

    // --- v1.33.4 (H3): the host transport follow ---
    //
    // The review: "the DAW's transport does not drive the app, so the plugin
    // can drift from the host" and "offer a clear internal/host clock
    // choice".
    //
    // The plugin reads the host's playhead in its audio callback and pushes
    // the values here as plain numbers - the component acts on them on the
    // message thread (the audio thread must not touch the UI). The values
    // cross the thread boundary, so they are atomic (the same rule as the
    // sample rate and the scrub tail).
    //
    // The mode is off by default: the app keeps its own clock, and the user
    // chooses the host's clock in the File menu.
    std::atomic<bool> hostTransportKnown { false };    // the host gave us a playhead
    std::atomic<bool> hostTransportPlaying { false };
    std::atomic<double> hostTransportPosSec { 0.0 };
    std::atomic<bool> followHostTransport { false };

public:
    bool isFollowingHostTransport() const { return followHostTransport.load (std::memory_order_relaxed); }
    void setFollowHostTransport (bool on);
    // the plugin pushes the host's transport here (the audio thread): it only
    // stores plain numbers, it never touches the UI
    void setHostTransport (bool known, bool playing, double posSec);
    // the message thread acts on the host's transport (the status timer)
    void applyHostTransport();

public:
    // --- v1.33.4 (L15, part 2): the undo stack ---
    //
    // The review: "core editing directly mutates vectors ... drawing,
    // erasure, deletion and accidental closing need a recovery path.
    // Introduce edit transactions, coalesce pointer drags into one undo
    // action".
    //
    // The stack holds snapshots of the model (the piece). The sample audio
    // is shared, so a snapshot costs only the pages - the audio is never
    // copied again and again. An edit pushes one snapshot: the state from
    // before it. A pointer drag is one transaction, so a drag is one undo
    // step (the pointer moves do not push anything).
    void beginEdit (const juce::String& label);
    void endEdit();
    bool canUndo() const { return ! undoStack.empty(); }
    bool canRedo() const { return ! redoStack.empty(); }
    juce::String undoLabel() const;
    juce::String redoLabel() const;
    int undoDepth() const { return (int) undoStack.size(); }
    int redoDepth() const { return (int) redoStack.size(); }
    void undo();
    void redo();

    // --- F2/F3 (2026-11-17): the wavetable and envelope libraries ---
    //
    // Each command is one user action: the caller wraps it in beginEdit/
    // endEdit, so the undo stack gets one snapshot per command (a delete
    // rewrites every reference in the same snapshot). A refusal returns
    // false and flashes the reason - the bank is never silently truncated.
    bool libraryNewWave();
    bool libraryDuplicateWave();
    bool libraryRenameWave (const juce::String& newName);
    bool libraryDeleteWave (int replacementId); // -1 when nothing uses it
    bool libraryMakeWaveUnique();

    bool libraryNewEnvelope();
    bool libraryDuplicateEnvelope();
    bool libraryRenameEnvelope (const juce::String& newName);
    bool libraryDeleteEnvelope (int replacementId);
    bool libraryMakeEnvelopeUnique();

    // WP7: the user-level library. Publishing copies an asset out of the
    // piece (it changes no model state); importing copies it back in with a
    // NEW local id (the caller wraps it in one undo transaction); Reveal
    // opens the library's folder.
    bool libraryPublishWave();
    bool libraryImportWave();
    bool libraryRevealWave();

    bool libraryPublishEnvelope();
    bool libraryImportEnvelope();
    bool libraryRevealEnvelope();

    bool libraryPublishAmpTable();
    bool libraryImportAmpTable();
    bool libraryRevealAmpTable();

    bool libraryPublishFreqTable();
    bool libraryImportFreqTable();
    bool libraryRevealFreqTable();

    bool libraryPublishSequence();
    bool libraryImportSequence();
    bool libraryRevealSequence();

    // WP7: the sample extraction panel. The panel itself is built lazily on
    // the message thread; these commands are the paths its buttons use.
    void openSampleExtractPanel();
    void closeSampleExtractPanel();
    void previewSampleExtract();
    bool saveSampleCycleToWave();
    bool saveSampleEnvelope();
    // Cancels the extraction route. The optional snapshot publication makes
    // the cancellation visible to the audio thread immediately.
    void resetSampleExtractRoute();
    void cancelSampleExtractPreview();
    // Cancels only the named extraction generation. A deferred host
    // lifecycle request uses this so it cannot cancel a newer preview.
    void cancelSampleExtractPreviewGeneration (std::uint64_t generation);
    // Advances the message-thread generation and publishes its atomic
    // mirror for host-thread lifecycle requests.
    void advanceSampleExtractPreviewGeneration();
    // A material replacement, piece load or undo makes a captured extraction
    // source stale. The panel is closed instead of silently saving a result
    // derived from material that is no longer in the piece.
    void invalidateSampleExtractSource();

    // v1.33.4 (M22): how many model snapshots were published (the timer
    // publishes only when the model changed). The selftest watches it.
    int modelSnapshotPublishCount() const { return snapshotPublishCount.load (std::memory_order_relaxed); }

    // v1.16: the host can only compensate ONE latency for the whole plugin,
    // and the score paths have none while the live path has a lot - so the
    // latency is only reported when the page is made of delayed paths alone.
    // The plugin (and only the plugin) publishes it to the host.
    std::function<void(int)> onLatencyChanged;
    int liveLatencySamples() const;
    void publishLatency();      // hand the current latency to the host
    int publishedLatency = -1;   // the value last handed to the host
    double getAudioSampleRate() const { return audioSampleRate(); }
    // v1.33.4 (L14): the rate the audio thread used in the last block (the
    // selftest watches it) and the tail length the slider wrote.
    int lastBlockRate() const { return lastBlockRateHz.load (std::memory_order_relaxed); }
    int scrubTailMsValue() const { return scrubTailMs.load (std::memory_order_relaxed); }
    // v1.33.4 (M23): the rate the exports use. The prepared rate is the
    // device's rate in standalone and the HOST's rate in a plugin - the
    // device manager knows nothing in a plugin, so the export used to fall
    // back to 44.1 kHz and sound different from the session.
    double exportSampleRate() const { const double sr = audioSampleRate(); return sr > 0.0 ? sr : 44100.0; }
    std::atomic<int> timerTicks { 0 };  // diagnostics: how often the status timer ran

    // --- v1.33.4 (M28): the long jobs off the message thread ---
    //
    // The job and its worker thread live in JobRunner.h; this class starts
    // them and shows their progress in the status line.
    using Job = upic::Job;

    // starts a job on the worker thread (message thread). One at a time: a
    // second job would fight the first over the disk.
    void startJob (const juce::String& label,
                   std::function<void (Job&)> work,
                   std::function<void (Job&)> report,
                   bool announce = true);
    void cancelJob();                                  // asks the running job to stop
    bool jobRunning() const { return jobs.running(); }
    int jobProgress() const { return jobs.progress(); }
    juce::String jobLabel() const { return jobs.label(); }

    // --- v1.33.4 (L15, part 3): the crash recovery ---
    //
    // The review asked for "recovery snapshots without embedding unchanged
    // audio repeatedly". The snapshot is a small piece JSON (the pages) plus
    // the audio in sidecar files: a sidecar is only written when the audio
    // really changed, so the repeated snapshots carry the pages, not the
    // material.
    //
    // The snapshot is written while the piece has unsaved changes (on the
    // worker thread, like the other long jobs) and it is offered at the next
    // start - the app asks whether to recover it.
    static juce::File recoveryDirectory();
    // writes the snapshot (the worker thread): the piece JSON and the
    // sidecars of the samples that changed
    static bool writeRecoverySnapshot (const juce::File& dir, const upic::PieceModel& model,
                                       juce::String& error);
    // reads it back (the message thread): the piece, with the audio put
    // back where the loader expects it
    static bool readRecoverySnapshot (const juce::File& dir, juce::var& pieceOut, juce::String& error);
    // throws it away (the piece was saved, or the user did not want it)
    static void deleteRecoverySnapshot (const juce::File& dir);
    // the message thread
    void offerRecovery();
    void maybeWriteRecoverySnapshot();
    // v1.33.4 (L15, part 3): the selftest must not write into the user's
    // own data folder, so it turns the snapshot off for its components.
    static void setRecoveryAllowed (bool allowed)
    {
        recoveryAllowed.store (allowed, std::memory_order_relaxed);
    }

    // The model a render or an export works on: captured on the message
    // thread (under the lock) and then never touched again.
    struct ExportModel
    {
        upic::Page page;
        std::vector<upic::Waveform> waves;
        std::vector<upic::Envelope> envs;
        std::vector<upic::Envelope> ampTables;  // WP2
        std::vector<upic::Channel> channels;    // WP6
            std::vector<upic::SampleSlot> slots;
        double sr = 44100.0;
        float masterGain = 0.8f;
        int samplePitchMode = 0, sampleGrainMs = 0, liveGrainMs = 0;
    };
    ExportModel captureExportModel() const;
    // The page render as a job (the file chooser calls it, and so does the
    // selftest). The destination can be a document-provider document too.
    void exportPageAsJob (const juce::URL& target);
    // The heavy work, on the calling thread (the worker thread in the app,
    // the selftest's thread in the test). The progress callback is called
    // with the percentage done and returns false to cancel the job.
    static bool exportPageToFile (const juce::File& target, const ExportModel& model,
                                  const std::function<bool (int percent)>& progress = {});
    static StemExport exportStemsToDir (const juce::File& dir, const ExportModel& model,
                                        const std::function<bool (int percent)>& progress = {});

    // The sample decode, off the message thread: the file is decoded into
    // the import, and the message thread installs it in the slot.
    struct SampleImport
    {
        juce::String name;
        upic::LoadedSample sample;
    };
    static bool decodeSampleFile (const juce::File& f, SampleImport& out, juce::String& error);
    void installSample (int slotIndex, SampleImport&& import);   // message thread

    // v1.20 (wave 18): the live reverse - the frozen segment the shifter
    // reads (mirrored in time) and the state of the effect.
    const juce::AudioBuffer<float>& reversePlaybackBuffer() const { return revBuf[revPlayIdx]; }
    int reverseBufferFrames() const { return revBufFrames.load(std::memory_order_relaxed); }
    bool reverseIsOn() const { return revLiveOn.load(std::memory_order_relaxed); }

    // v1.23 (wave 20): the MIDI foundation, for the selftest.
    MidiHub& midiHub() { return midi; }

    // v1.29: the OSC scrub receiver (phone/MobMuPlat).
    bool oscIsListening() const { return osc.isListening(); }
    int oscPortForTest() const { return osc.getPort(); }
    int oscMulticastPortForTest() const { return osc.getMulticastPort(); }
    juce::String oscMulticastGroupForTest() const { return osc.getMulticastGroup(); }
    bool settingsVisibleForTest() const { return settingsOverlay.isVisible(); }
    bool oscEnabledForTest() const { return osc.isEnabled(); }
    // WP7: the host-preparation generation is current only after the
    // message thread has applied the requested rate and block size.
    bool audioPreparationIsCurrentForTest() const
    {
        const auto requested = requestedAudioPreparationGeneration.load (
            std::memory_order_acquire);
        return requested != 0
            && requested == publishedAudioPreparationGeneration.load (
                std::memory_order_acquire);
    }
    std::uint64_t audioPreparationGenerationForTest() const
    { return publishedAudioPreparationGeneration.load (std::memory_order_acquire); }
    double pageDurationForTest() const { return curPage().durationSec; }
    // v1.33: the page's four spaces and an arc's space, so the selftest can
    // check that the controls really reach the model.
    int pageSpaceForTest (int i) const { return curPage().spaces[(size_t) juce::jlimit (0, 3, i)]; }
    // WP1: the drawn tables, through the same paths the Table... button and
    // the editor use.
    bool spaceDefEditableForTest (int i) const
    { return curPage().spaceDefs[(size_t) juce::jlimit (0, 3, i)].editable; }
    int spaceDefPointCountForTest (int i) const
    { return (int) curPage().spaceDefs[(size_t) juce::jlimit (0, 3, i)].points.size(); }
    bool freqTableOpenForTest() const { return freqTableEd.isVisible(); }
    int freqTablePageForTest() const { return freqTablePage; }
    int freqTableSpaceForTest() const { return freqTableSpace; }
    // WP7: the frequency table's destination is captured at open time. The
    // test moves the current page afterwards to prove that an import still
    // lands in the captured page/space.
    void setCurrentPageForTest (int page)
    {
        currentPage = juce::jlimit (0, juce::jmax (0, (int) pages.size() - 1), page);
    }
    bool pageSpaceDefEditableForTest (int page, int space) const
    {
        if (page < 0 || page >= (int) pages.size()) return false;
        return pages[(size_t) page].spaceDefs[(size_t) juce::jlimit (0, 3, space)].editable;
    }
    int pageSpaceDefPointCountForTest (int page, int space) const
    {
        if (page < 0 || page >= (int) pages.size()) return -1;
        return (int) pages[(size_t) page].spaceDefs[(size_t) juce::jlimit (0, 3, space)].points.size();
    }
    void openFreqTableForTest (int s) { showFreqTableEditor (s); }
    void commitFreqTableCurveForTest (const std::vector<upic::TablePoint>& pts)
    { freqTableEd.commitCurveForTest (pts); }
    void commitFreqTableFlagsForTest() { freqTableEd.commitFlagsForTest(); }
    // WP2: the amplitude table bank, through the paths the UI uses.
    int ampTableCountForTest() const { return (int) ampTables.size(); }
    int ampTableIdAtForTest (int i) const
    { return (i >= 0 && i < (int) ampTables.size()) ? ampTables[(size_t) i].id : -1; }
    float ampTableValueForTest (int i, float x) const
    { return (i >= 0 && i < (int) ampTables.size()) ? ampTables[(size_t) i].valueAt (x) : x; }
    int arcAmpTableIdForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.amplitudeTableId;
        return -2;
    }
    bool ampTableEditorOpenForTest() const { return ampTableEd.isVisible(); }
    void openAmpTableEditorForTest() { showAmpTableEditor(); }
    void ampTableDrawForTest (const std::vector<upic::EnvPoint>& pts)
    { ampTableEd.drawCurveForTest (pts); }
    void ampTableSelectForTest (int index) { ampTableEd.selectRowForTest (index); }
    void ampTableAssignForTest (int id) { applyAmpTableToSelection (id); }
    void ampTableNewForTest() { ampTableEd.newForTest(); }
    void ampTableDeleteForTest() { ampTableEd.deleteForTest(); }
    void ampTableDuplicateForTest() { ampTableEd.duplicateForTest(); }
    void ampTableRenameForTest (const juce::String& n) { ampTableEd.renameForTest (n); }
    // WP3: the groups, through the panel's commands.
    int groupCountForTest() const { return (int) curPage().groups.size(); }
    int channelCountForTest() const { return (int) channels.size(); }
    int channelIdAtForTest (int i) const { return (i >= 0 && i < (int) channels.size()) ? channels[(size_t) i].id : -1; }
    float channelGainAtForTest (int i) const { return (i >= 0 && i < (int) channels.size()) ? channels[(size_t) i].gain : -1.0f; }
    int channelEnvelopePointsAtForTest (int i) const { return (i >= 0 && i < (int) channels.size()) ? (int) channels[(size_t) i].envelope.size() : -1; }
    // --- WP6.4 test accessors ---
    bool channelMutedAtForTest (int i) const { return i >= 0 && i < (int) channels.size() && channels[(size_t) i].muted; }
    bool channelSoloAtForTest (int i) const { return i >= 0 && i < (int) channels.size() && channels[(size_t) i].solo; }
    bool channelPanelOpenForTest() const { return channelPanel != nullptr && channelPanel->isVisible(); }
    void openChannelPanelForTest() { showChannelPanel(); }
    void closeChannelPanelForTest() { closeChannelPanel(); }
    void channelNewForTest() { if (channelPanel != nullptr) channelPanel->newForTest(); }
    void channelDeleteForTest() { if (channelPanel != nullptr) channelPanel->deleteForTest(); }
    void channelSelectForTest (int i) { if (channelPanel != nullptr) channelPanel->selectForTest (i); }
    void channelMuteForTest (bool on) { if (channelPanel != nullptr) channelPanel->muteForTest (on); }
    void channelSoloForTest (bool on) { if (channelPanel != nullptr) channelPanel->soloForTest (on); }
    void channelGainForTest (float v) { if (channelPanel != nullptr) channelPanel->gainForTest (v); }
    void channelGainDragStartForTest() { if (channelPanel != nullptr) channelPanel->gainDragStartForTest(); }
    void channelGainDragEndForTest() { if (channelPanel != nullptr) channelPanel->gainDragEndForTest(); }
    void channelCurveForTest (const std::vector<upic::EnvPoint>& pts) { if (channelPanel != nullptr) channelPanel->curveForTest (pts); }
    void channelRenameForTest (const juce::String& n) { if (channelPanel != nullptr) channelPanel->renameForTest (n); }
    void channelAssignForTest (int id) { setChannelOnSelection (id); }
    // L3: the mixer list's scroll position (the first visible row).
    int channelListScrollForTest() const
    { return channelPanel != nullptr ? channelPanel->listScrollForTest() : 0; }
    int channelListVisibleRowsForTest() const
    { return channelPanel != nullptr ? channelPanel->visibleRowsForTest() : 0; }
    void channelListScrollForTest (int row)
    { if (channelPanel != nullptr) channelPanel->scrollListToForTest (row); }
    // --- end WP6.4 ---
    int arcChannelForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.channelId;
        return -2;
    }
    // The toolbar's combo boxes, so the selftest can check that they follow
    // the selected arc.
    int channelBoxSelectionForTest() const { return channelBox.getSelectedId(); }
    int ampTableBoxSelectionForTest() const { return ampTableBox.getSelectedId(); }
    int arcModBoxSelectionForTest() const { return arcModBox.getSelectedId(); }
    int arcModTargetSelectionForTest() const { return arcModTgtBox.getSelectedId(); }
    int groupIdAtForTest (int i) const
    { return (i >= 0 && i < (int) curPage().groups.size()) ? curPage().groups[(size_t) i].id : -1; }
    int groupMemberCountAtForTest (int i) const
    { return (i >= 0 && i < (int) curPage().groups.size()) ? (int) curPage().groups[(size_t) i].arcIds.size() : -1; }
    int arcGroupIdForTest (int arcId) const
    {
        for (auto& g : curPage().groups)
            for (int aid : g.arcIds) if (aid == arcId) return g.id;
        return -1;
    }
    bool groupPanelOpenForTest() const { return groupPanel.isVisible(); }
    void openGroupPanelForTest() { showGroupPanel(); }
    void groupNewForTest() { groupPanel.newForTest(); }
    void groupDeleteForTest() { groupPanel.deleteForTest(); }
    void groupAddSelForTest() { groupPanel.addSelForTest(); }
    void groupRemoveSelForTest() { groupPanel.removeSelForTest(); }
    void groupSelectMembersForTest() { groupPanel.selectMembersForTest(); }
    void groupMuteForTest (bool on) { groupPanel.setMuteForTest (on); }
    void groupSoloForTest (bool on) { groupPanel.setSoloForTest (on); }
    void groupGainForTest (float v) { groupPanel.setGainForTest (v); }
    void groupTransposeForTest (double v) { groupPanel.setTransposeForTest (v); }
    void groupOverrideForTest (int kind, int id) { groupPanel.setOverrideForTest (kind, id); }
    void groupRenameForTest (const juce::String& n) { groupPanel.renameForTest (n); }
    int selectedGroupIdForTest() const { return selGroupId; }
    // WP4: the sequences.
    int seqCountForTest() const { return (int) sequences.size(); }
    int seqIdAtForTest (int i) const
    { return (i >= 0 && i < (int) sequences.size()) ? sequences[(size_t) i].id : -1; }
    int seqPointCountAtForTest (int i) const
    { return (i >= 0 && i < (int) sequences.size()) ? (int) sequences[(size_t) i].points.size() : -1; }
    juce::String seqNameAtForTest (int i) const
    { return (i >= 0 && i < (int) sequences.size()) ? sequences[(size_t) i].name : juce::String(); }
    bool seqLoopAtForTest (int i) const
    { return i >= 0 && i < (int) sequences.size() && sequences[(size_t) i].loop; }
    int selectedSeqIdForTest() const { return selSeqId; }
    bool seqRecordingForTest() const { return seqRecording; }
    bool seqPlayActiveForTest() const { return seqPlayActive.load(); }
    bool seqPanelOpenForTest() const { return seqPanel.isVisible(); }
    void openSeqPanelForTest() { showSequencePanel(); }
    void seqRecordToggleForTest() { seqPanel.recordForTest(); }
    void seqPlayToggleForTest() { seqPanel.playForTest(); }
    void seqClearForTest() { seqPanel.clearForTest(); }
    void seqLoopToggleForTest() { seqPanel.loopForTest(); }
    void seqSelectPointForTest (int i) { seqPanel.selectPointForTest (i); }
    void seqTrimForTest() { seqPanel.trimForTest(); }
    void seqReplaceForTest() { seqPanel.replaceForTest(); }
    void seqDragPointForTest (int i, double t, int page, double pos)
    { seqPanel.dragPointForTest (i, t, page, pos); }
    void seqAppendForTest (double t, int page, double pos)
    { sequenceAppendRecorderPoint (t, page, pos); }
    double seqPointTAtForTest (int i, int j) const
    { return (i >= 0 && i < (int) sequences.size() && j >= 0 && j < (int) sequences[(size_t) i].points.size()) ? sequences[(size_t) i].points[(size_t) j].t : -1.0; }
    int seqPointPageAtForTest (int i, int j) const
    { return (i >= 0 && i < (int) sequences.size() && j >= 0 && j < (int) sequences[(size_t) i].points.size()) ? sequences[(size_t) i].points[(size_t) j].page : -1; }
    double seqPointPosAtForTest (int i, int j) const
    { return (i >= 0 && i < (int) sequences.size() && j >= 0 && j < (int) sequences[(size_t) i].points.size()) ? sequences[(size_t) i].points[(size_t) j].pos : -1.0; }
    bool groupMutedAtForTest (int i) const
    { return i >= 0 && i < (int) curPage().groups.size() && curPage().groups[(size_t) i].muted; }
    bool groupSoloAtForTest (int i) const
    { return i >= 0 && i < (int) curPage().groups.size() && curPage().groups[(size_t) i].solo; }
    float groupGainAtForTest (int i) const
    { return i >= 0 && i < (int) curPage().groups.size() ? curPage().groups[(size_t) i].gain : -1.0f; }
    double groupTransposeAtForTest (int i) const
    { return i >= 0 && i < (int) curPage().groups.size() ? curPage().groups[(size_t) i].transposeSemitones : 0.0; }
    int arcModulatorForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.modulatorArcId;
        return -2;
    }
    int arcModTargetForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.modTarget;
        return -1;
    }
    double arcModDepthForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.modArcDepth;
        return -1.0;
    }
    void modApplyForTest (int modId, int target, double depth)
    { setModOnSelection (modId, target, depth); }
    int groupOverrideAtForTest (int i, int kind) const
    {
        if (i < 0 || i >= (int) curPage().groups.size()) return -2;
        const auto& g = curPage().groups[(size_t) i];
        return kind == 0 ? g.waveformId : (kind == 1 ? g.envelopeId
                                  : (kind == 2 ? g.amplitudeTableId : g.channelId));
    }
    int arcSpaceForTest (int arcId) const
    {
        for (auto& a : curPage().arcs) if (a.id == arcId) return a.space;
        return -1;
    }
    double pageWarpForTest() const { return curPage().warp; }
    // v1.33.4 (H13): the page's arc count and the last status message, so
    // the selftest can check that the editor refuses the arc that does not
    // fit and that the loader says what it had to drop.
    int arcCountForTest() const { return (int) curPage().arcs.size(); }
    int nextArcIdForTest() const { return curPage().nextArcId; }
    ScoreEditor& scoreEditorForTest() { return score; }
    bool waveFromSelectedSlotForTest() { return waveFromSelectedSlot(); }
    int zoneCountForTest() const { return (int) curPage().zones.size(); }
    int pageCountForTest() const { return (int) pages.size(); }
    juce::String flashMessageForTest() const { return flashMsg; }
    // --- F2/F3: the wavetable and envelope libraries ---
    int waveformCountForTest() const { return (int) waveforms.size(); }
    int envelopeCountForTest() const { return (int) envelopes.size(); }
    int selectedWaveformIdForTest() const { return selWave; }
    int selectedEnvelopeIdForTest() const { return selEnv; }
    int waveformIdForTest (int i) const
    {
        return i >= 0 && i < (int) waveforms.size() ? waveforms[(size_t) i].id : -1;
    }
    int envelopeIdForTest (int i) const
    {
        return i >= 0 && i < (int) envelopes.size() ? envelopes[(size_t) i].id : -1;
    }
    juce::String waveformNameForTest (int i) const
    {
        return i >= 0 && i < (int) waveforms.size() ? waveforms[(size_t) i].name : juce::String();
    }
    juce::String envelopeNameForTest (int i) const
    {
        return i >= 0 && i < (int) envelopes.size() ? envelopes[(size_t) i].name : juce::String();
    }
    float waveformSampleForTest (int id, int i) const
    {
        for (const auto& w : waveforms)
            if (w.id == id && i >= 0 && i < (int) w.samples.size())
                return w.samples[(size_t) i];
        return 0.0f;
    }
    int waveformUseCountForTest (int id) const { return waveUseCount (id); }
    int envelopeUseCountForTest (int id) const { return envelopeUseCount (id); }
    // F2/F3: the library manager's own state (the UI checks) and the arc
    // references (the delete tests).
    void selectWaveformForTest (int id)
    {
        selWave = id;
        waveEd.bind (&waveforms, &selWave, [this]{ markModelChanged(); });
        refreshBoxes();
        pushVoice();
    }
    void selectEnvelopeForTest (int id)
    {
        selEnv = id;
        envEd.bind (&envelopes, &selEnv, [this]{ markModelChanged(); });
        refreshBoxes();
        pushVoice();
    }
    int selectedLibraryWaveForTest() const { return waveLib.selectedAssetId(); }
    int selectedLibraryEnvelopeForTest() const { return envLib.selectedAssetId(); }
    int libraryWaveItemCountForTest() const { return waveLib.itemCountForTest(); }
    int libraryEnvelopeItemCountForTest() const { return envLib.itemCountForTest(); }
    int libraryWaveUsesForTest (int index) const { return waveLib.usesForTest (index); }
    int libraryEnvelopeUsesForTest (int index) const { return envLib.usesForTest (index); }
    bool waveLibraryRenameModeForTest() const { return waveLib.isRenameModeForTest(); }
    bool waveLibraryDeleteModeForTest() const { return waveLib.isDeleteModeForTest(); }
    bool envLibraryRenameModeForTest() const { return envLib.isRenameModeForTest(); }
    bool envLibraryDeleteModeForTest() const { return envLib.isDeleteModeForTest(); }
    // WP7: the user-library half of the two managers. The tests switch the
    // source, publish and import through the same paths the buttons use.
    void libraryWaveSourceForTest (bool user) { waveLib.setSourceForTest (user); }
    void libraryEnvelopeSourceForTest (bool user) { envLib.setSourceForTest (user); }
    int libraryWaveUserItemCountForTest() const { return waveLib.userItemCountForTest(); }
    int libraryEnvelopeUserItemCountForTest() const { return envLib.userItemCountForTest(); }
    juce::String libraryWaveUserFileForTest() const { return waveLib.selectedFileNameForTest(); }
    juce::String libraryEnvelopeUserFileForTest() const { return envLib.selectedFileNameForTest(); }
    void libraryWaveSelectUserForTest (int index)
    { waveLib.selectIndexForTest (index); }
    void libraryEnvelopeSelectUserForTest (int index)
    { envLib.selectIndexForTest (index); }
    bool libraryPublishWaveForTest() { return libraryPublishWave(); }
    bool libraryImportWaveForTest() { return libraryImportWave(); }
    bool libraryPublishEnvelopeForTest() { return libraryPublishEnvelope(); }
    bool libraryImportEnvelopeForTest() { return libraryImportEnvelope(); }
    // Transaction-exact variants: these use the same one beginEdit/endEdit
    // boundary as the manager's Import button.
    bool libraryImportWaveTransactionForTest()
    { beginEdit ("Import the wavetable"); const bool ok = libraryImportWave(); endEdit(); return ok; }
    bool libraryImportEnvelopeTransactionForTest()
    { beginEdit ("Import the envelope"); const bool ok = libraryImportEnvelope(); endEdit(); return ok; }
    bool libraryImportAmpTableTransactionForTest()
    { beginEdit ("Import the amplitude table"); const bool ok = libraryImportAmpTable(); endEdit(); return ok; }
    bool libraryImportFreqTableTransactionForTest()
    { beginEdit ("Import the frequency table"); const bool ok = libraryImportFreqTable(); endEdit(); return ok; }
    bool libraryImportSequenceTransactionForTest()
    { beginEdit ("Import the performance sequence"); const bool ok = libraryImportSequence(); endEdit(); return ok; }

    void libraryAmpTableSourceForTest (bool user)
    { ampTableEd.library.setSourceForTest (user); }
    void libraryFreqTableSourceForTest (bool user)
    { freqTableEd.library.setSourceForTest (user); }
    void librarySequenceSourceForTest (bool user)
    { seqPanel.library.setSourceForTest (user); }
    int libraryAmpTableUserItemCountForTest() const
    { return ampTableEd.library.userItemCountForTest(); }
    int libraryFreqTableUserItemCountForTest() const
    { return freqTableEd.library.userItemCountForTest(); }
    int librarySequenceUserItemCountForTest() const
    { return seqPanel.library.userItemCountForTest(); }
    int libraryAmpTableItemCountForTest() const
    { return ampTableEd.library.itemCountForTest(); }
    int libraryFreqTableItemCountForTest() const
    { return freqTableEd.library.itemCountForTest(); }
    int librarySequenceItemCountForTest() const
    { return seqPanel.library.itemCountForTest(); }
    juce::String libraryAmpTableUserFileForTest() const
    { return ampTableEd.library.selectedFileNameForTest(); }
    juce::String libraryFreqTableUserFileForTest() const
    { return freqTableEd.library.selectedFileNameForTest(); }
    juce::String librarySequenceUserFileForTest() const
    { return seqPanel.library.selectedFileNameForTest(); }
    void libraryAmpTableSelectUserForTest (int index)
    { ampTableEd.library.selectIndexForTest (index); }
    void libraryFreqTableSelectUserForTest (int index)
    { freqTableEd.library.selectIndexForTest (index); }
    void librarySequenceSelectUserForTest (int index)
    { seqPanel.library.selectIndexForTest (index); }
    bool libraryPublishAmpTableForTest() { return libraryPublishAmpTable(); }
    bool libraryPublishFreqTableForTest() { return libraryPublishFreqTable(); }
    bool libraryPublishSequenceForTest() { return libraryPublishSequence(); }
    bool libraryImportAmpTableForTest() { return libraryImportAmpTable(); }
    bool libraryImportFreqTableForTest() { return libraryImportFreqTable(); }
    bool libraryImportSequenceForTest() { return libraryImportSequence(); }
    void refreshUserLibraryForTest (upic::UserAssetKind kind)
    { refreshUserLibraryBoxes (kind); }
    juce::String lastUserLibraryFailureTextForTest() const
    { return lastUserLibraryFailureText; }

    // WP7: the sample extraction panel and a synthetic material for its
    // checks. The material is installed exactly like a decoded file.
    bool sampleExtractPanelOpenForTest() const
    { return sampleExtractPanel != nullptr && sampleExtractPanel->isVisible(); }
    // WP7: the overlay closes with Escape, like the other editors.
    bool sampleExtractEscapeForTest()
    {
        if (sampleExtractPanel == nullptr) return false;
        return sampleExtractPanel->keyPressed (
            juce::KeyPress (juce::KeyPress::escapeKey));
    }
    void openSampleExtractForTest() { openSampleExtractPanel(); }
    void closeSampleExtractForTest() { closeSampleExtractPanel(); }
    void sampleExtractDetectForTest()
    {
        if (sampleExtractPanel == nullptr) return;
        // Use the panel's command callback, not the analysis method alone:
        // the real Detect button also refreshes the published preview route.
        if (sampleExtractPanel->onDetect) sampleExtractPanel->onDetect();
        else sampleExtractPanel->analyse();
    }
    void sampleExtractAlignForTest()
    {
        if (sampleExtractPanel == nullptr) return;
        if (sampleExtractPanel->onAlign) sampleExtractPanel->onAlign();
        else sampleExtractPanel->alignCycle();
    }
    void sampleExtractPreviewForTest() { previewSampleExtract(); }
    void cancelSampleExtractPreviewGenerationForTest (std::uint64_t generation)
    { cancelSampleExtractPreviewGeneration (generation); }
    // WP7: the ordinary routes are cancelled on their own (a model
    // replacement, a transport start). The helper must never take the
    // extraction route with it.
    void cancelOrdinaryPreviewRoutesForTest() { cancelOrdinaryPreviewRoutes(); }
    bool sampleExtractPreviewUsesCycleForTest() const
    { return sampleExtractPanel != nullptr && sampleExtractPanel->isPreviewExtracted(); }
    bool sampleExtractPreviewActiveForTest() const
    { return sampleExtractPreviewState.route != SampleExtractRoute::none; }
    SampleExtractRoute sampleExtractPreviewRouteForTest() const
    { return sampleExtractPreviewState.route; }
    uint64_t sampleExtractPreviewGenerationForTest() const
    { return sampleExtractPreviewState.generation; }
    int sampleExtractCycleLengthForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->cycleLengthForTest() : 0; }
    int sampleExtractCycleStartForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->cycleStartForTest() : 0; }
    int sampleExtractSourceSlotIdForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->sourceSlotIdForTest() : -1; }
    std::vector<upic::EnvPoint> sampleExtractEnvelopePointsForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->envelopePointsForTest()
                                           : std::vector<upic::EnvPoint>(); }
    int sampleExtractAnalysisChannelForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->analysisChannelForTest() : -1; }
    int sampleExtractSourceChannelCountForTest() const
    { return sampleExtractPanel != nullptr ? sampleExtractPanel->sourceChannelCountForTest() : 0; }
    void sampleExtractSelectChannelForTest (int channel)
    {
        if (sampleExtractPanel == nullptr) return;
        sampleExtractPanel->setSourceChannelForTest (channel);
        if (sampleExtractPanel->isPreviewOn())
            restartSampleExtractPreview();
    }
    bool sampleExtractPreviewRequestedExtractedForTest() const
    { return sampleExtractPanel != nullptr
          && sampleExtractPanel->previewRequestedExtractedForTest(); }
    int sampleExtractPreviewWaveSizeForTest() const
    { return sampleExtractPanel != nullptr
          ? (int) sampleExtractPanel->previewWaveformForTest().samples.size() : 0; }
    float sampleExtractPreviewWaveSampleForTest (int i) const
    {
        if (sampleExtractPanel == nullptr) return 0.0f;
        const auto& samples = sampleExtractPanel->previewWaveformForTest().samples;
        return i >= 0 && i < (int) samples.size() ? samples[(size_t) i] : 0.0f;
    }
    void sampleExtractSetEnvelopeModeForTest (upic::EnvelopeMode mode)
    { if (sampleExtractPanel) sampleExtractPanel->setEnvelopeModeForTest (mode); }
    bool setSampleSlotForTest (int slotIndex, const juce::AudioBuffer<float>& data, double sampleRate);
    bool sampleTrimForTest (int startFrame, int endFrame)
    { return waveEd.trimSampleForTest (startFrame, endFrame); }
    void sampleReverseForTest()
    {
        revBtn.setToggleState (! revBtn.getToggleState(), juce::dontSendNotification);
        revBtn.onClick();
    }
    void sampleMaterialModeForTest()
    {
        drawMatMode = 1;
        updateSampleView();
    }
    void sampleRefForTest (double hz)
    {
        drawMatMode = 1;
        refSlider.setValue (hz, juce::dontSendNotification);
        refSlider.onValueChange();
    }
    void sampleLevelForTest (double level)
    {
        levelSlider.setValue (level, juce::dontSendNotification);
        levelSlider.onValueChange();
    }
    bool sampleExtractPreviewMatchesWaveForTest (int waveId) const
    {
        if (sampleExtractPanel == nullptr) return false;
        const auto& preview = sampleExtractPanel->previewWaveformForTest();
        for (const auto& wave : waveforms)
        {
            if (wave.id != waveId || wave.samples.size() != preview.samples.size()) continue;
            return std::memcmp (wave.samples.data(), preview.samples.data(),
                                wave.samples.size() * sizeof (float)) == 0;
        }
        return false;
    }
    bool sampleExtractSnapshotMatchesPreviewForTest() const
    {
        if (sampleExtractPanel == nullptr
            || publishedSampleExtractPreview.state.route != SampleExtractRoute::extracted)
            return false;
        const auto& preview = sampleExtractPanel->previewWaveformForTest();
        // Read the isolated vector directly. The renderer's route accessor is
        // deliberately not part of this check: a renderer that accidentally
        // selected the piece's same-id wave must fail this test.
        const auto& routeWaves = publishedSampleExtractPreview.waves;
        if (routeWaves.size() != 1 || preview.samples.size() != routeWaves.front().samples.size())
            return false;
        return std::memcmp (preview.samples.data(), routeWaves.front().samples.data(),
                            preview.samples.size() * sizeof (float)) == 0;
    }
    bool sampleExtractSnapshotUsesSourceChannelForTest (int channel, int frame) const;
    bool sampleExtractRenderedMatchesIsolatedWaveForTest (
        const juce::AudioBuffer<float>& rendered, int blockSize) const;
    void sampleExtractScrubForTest (double timeSec)
    {
        if (score.onScrubPreview) score.onScrubPreview (timeSec);
    }
    void sampleExtractFreezeForTest (double timeSec)
    {
        if (score.onScrubFreezeStart) score.onScrubFreezeStart (timeSec);
    }
    void sampleExtractFreezeStopForTest()
    {
        if (score.onScrubFreezeStop) score.onScrubFreezeStop();
    }
    void sampleExtractFreezeCancelForTest()
    {
        if (score.onScrubFreezeCancel) score.onScrubFreezeCancel();
    }

    // WP7 route arbitration: force a route change immediately after the
    // audio callback has taken its snapshot. This reproduces the former
    // extraction/scrub race deterministically: the snapshot is still the old
    // one, while the route token and the ordinary-route flags are already
    // the new ones. -1 clears the override. The optional generation offset
    // lets the test force an old snapshot/new extraction-generation pair.
    void setAudioPreviewRouteOverrideForTest (int route, int generationOffset = 0)
    {
        const auto packed = route < 0
            ? ~std::uint64_t { 0 }
            : (static_cast<std::uint64_t> (static_cast<std::uint32_t> (route))
               | (static_cast<std::uint64_t> (
                      static_cast<std::uint32_t> (juce::jmax (0, generationOffset)))
                  << 32));
        audioPreviewRouteTestOverride.store (packed, std::memory_order_release);
    }
    // Selftest-only: make the next audio callback take the null-snapshot
    // path. This changes no handover pointer and is safe even if a host
    // callback is active; production code never retires a live snapshot
    // from the message thread.
    void setAudioPreviewSkipSnapshotForTest (bool skip)
    {
        audioPreviewSkipSnapshotForTest.store (skip, std::memory_order_relaxed);
    }
    AudioPreviewRoute audioPreviewRouteForTest() const
    {
        return audioPreviewRouteFromToken (audioPreviewRouteToken.load (
            std::memory_order_acquire));
    }
    std::uint64_t audioPreviewRouteGenerationForTest() const
    {
        return audioPreviewGenerationFromToken (audioPreviewRouteToken.load (
            std::memory_order_acquire));
    }
    std::uint64_t ordinaryPreviewGenerationForTest() const
    {
        return ordinaryPreviewGeneration.load (std::memory_order_acquire);
    }
    // Selftest-only: pause the next ordinary route claim after it captures
    // its lifecycle epoch. The host boundary can then run before the claim
    // takes the route lock, making the stale-epoch rejection deterministic.
    void pauseNextAudioPreviewRouteClaimForTest()
    {
        audioPreviewRouteClaimPausedFlagForTest.store (false, std::memory_order_relaxed);
        audioPreviewRouteClaimResumeForTest.store (false, std::memory_order_relaxed);
        audioPreviewRouteClaimPauseRequestedForTest.store (true, std::memory_order_release);
    }
    bool audioPreviewRouteClaimPausedForTest() const
    {
        return audioPreviewRouteClaimPausedFlagForTest.load (std::memory_order_acquire);
    }
    void resumeAudioPreviewRouteClaimForTest()
    {
        audioPreviewRouteClaimResumeForTest.store (true, std::memory_order_release);
    }
    AudioPreviewRoute audioPreviewRouteSeenForTest() const
    {
        return audioPreviewRouteFromToken (audioPreviewRouteTokenSeenForTest.load (
            std::memory_order_acquire));
    }
    std::uint64_t audioPreviewRouteGenerationSeenForTest() const
    {
        return audioPreviewGenerationFromToken (audioPreviewRouteTokenSeenForTest.load (
            std::memory_order_acquire));
    }
    bool sampleExtractPublishedRouteIsNoneForTest() const
    {
        const auto state = publishedSampleExtractSnapshotState.load (
            std::memory_order_acquire);
        return static_cast<SampleExtractRoute> (state & 3u)
                 == SampleExtractRoute::none
            && (state & 4u) == 0;
    }
    bool scrubPreviewActiveForTest() const
    {
        return ordinaryPreviewState.scrubActive;
    }
    bool scrubFreezeActiveForTest() const
    {
        return ordinaryPreviewState.freezeActive;
    }
    int scrubPreviewRemainingForTest() const
    {
        return ordinaryPreviewState.scrubRemaining;
    }
    double scrubFreezeStopAtForTest() const
    {
        return ordinaryPreviewState.freezeStopAtMs;
    }
    double scrubFreezeTransitionStartForTest() const
    {
        return ordinaryPreviewState.transitionStartMs;
    }
    double scrubFreezeTransitionEndForTest() const
    {
        return ordinaryPreviewState.transitionEndMs;
    }
    std::uint64_t ordinaryPreviewCoherenceFailureCountForTest() const
    {
        return ordinaryPreviewCoherenceFailureCount.load (std::memory_order_relaxed);
    }
    bool audioFreezeActiveForTest() const { return audioFreezeActive; }
    bool audioFreezeExpiredForTest() const { return audioFreezeExpired; }
    std::uint64_t audioFreezeGenerationForTest() const { return audioFreezeGeneration; }
    std::shared_ptr<std::atomic<bool>> audioPreviewCallbackGateClosedFlagForTest() const
    {
        // An aliasing shared_ptr: it keeps the gate alive and observes the
        // gate's own "closed" flag, so the production code carries one
        // allocation for the gate and no separate observer.
        if (audioPreviewCallbackGate == nullptr)
            return {};

        return std::shared_ptr<std::atomic<bool>> (audioPreviewCallbackGate,
                                                   &audioPreviewCallbackGate->closed);
    }
    void sampleExtractFreezeStopAtForTest (double stopAtMs)
    { updateScrubFreezeStop (stopAtMs); }
    int arcWaveformIdForTest (int arcId) const
    {
        for (const auto& a : curPage().arcs) if (a.id == arcId) return a.waveformId;
        return -1;
    }
    int arcEnvelopeIdForTest (int arcId) const
    {
        for (const auto& a : curPage().arcs) if (a.id == arcId) return a.envelopeId;
        return -1;
    }
    int arcPmIndexEnvForTest (int arcId) const
    {
        for (const auto& a : curPage().arcs) if (a.id == arcId) return a.pmIndexEnv;
        return -1;
    }
    int pageArcWaveformIdForTest (int page, int arcId) const
    {
        if (page < 0 || page >= (int) pages.size()) return -1;
        for (const auto& a : pages[(size_t) page].arcs) if (a.id == arcId) return a.waveformId;
        return -1;
    }
    int pageArcEnvelopeIdForTest (int page, int arcId) const
    {
        if (page < 0 || page >= (int) pages.size()) return -1;
        for (const auto& a : pages[(size_t) page].arcs) if (a.id == arcId) return a.envelopeId;
        return -1;
    }
    int pageArcPmIndexEnvForTest (int page, int arcId) const
    {
        if (page < 0 || page >= (int) pages.size()) return -1;
        for (const auto& a : pages[(size_t) page].arcs) if (a.id == arcId) return a.pmIndexEnv;
        return -1;
    }
    void selectArcsForTest (const std::vector<int>& ids) { score.setSelectedArcs (ids); }
    // The same selection, but the toolbar's combos are brought in line with
    // it - the selection callback the score editor fires when the user
    // clicks an arc. The plain selectArcsForTest deliberately does NOT do
    // that: the existing checks drive the model, not the toolbar.
    void selectArcsAndSyncForTest (const std::vector<int>& ids)
    {
        score.setSelectedArcs (ids);
        selectedArcId = score.getSelectedArc();
        lastArcSelection = score.getSelectedArcs();
        syncControlsToArc (selectedArcId);
    }
    int selectedArcCountForTest() const { return (int) score.getSelectedArcs().size(); }

    // --- F5 (2026-11-17): the toolbar's disclosure sections --------------
    // Every group has a disclosure toggle captioned with the group's name
    // (the "Scrub settings" pattern of the visual refinement): the toggle
    // is always visible, and it expands or collapses that group's controls.
    // The state is session state (the levels never enter the piece), and
    // the permanent strip keeps Menu, Play/Stop, the tool and Restore
    // visible whatever the groups do.
    enum class GroupLevel : int { expanded = 0, collapsed = 1 };
    void setGroupLevel (const juce::String& group, GroupLevel level);
    GroupLevel groupLevelFor (const juce::String& group) const;
    void restoreAllGroups();
    // The caption of a group's disclosure toggle.
    static juce::String groupCaption (const juce::String& group);
    // The session settings' value-tree round trip. The app persists it; the
    // selftest calls the two functions directly (no file is touched).
    juce::var sessionSettingsToVar() const;
    void sessionSettingsFromVar (const juce::var& v);
    static void setSessionSettingsPersistent (bool on);
    // The permanent strip's controls, for the layout checks.
    juce::Rectangle<int> permanentStripBoundsForTest() const { return permanentStripBounds; }
    int toolbarRowCountForTest() const { return toolbarRows; }
    // v1.33.4 (H7): the global pitch modes (they change the sound, so the
    // selftest checks that they survive a save and a load)
    int samplePitchModeForTest() const { return engine.getSamplePitchMode(); }
    int livePitchModeForTest() const { return engine.getLivePitchMode(); }
    double playheadForTest() const { return playheadSec; }
    double publishedPlayheadForTest() const
    {
        return playheadPublished.load (std::memory_order_relaxed);
    }
    // v1.33.4 (M24): the peak the input tap saw on a channel - the plugin
    // smoke test checks that the host's right input channel reaches the app
    // even when the host's output is mono.
    float inputTapPeakForTest (int channel) const;
    bool externalScrubActiveForTest() const { return externalScrubActive; }
    // --- F1: the transport state machine (2026-11-17) ---
    // Stopped -> Starting (Play) -> Playing; Playing -> Stopping (Stop) ->
    // Stopped. Play while Starting/Playing is a no-op; Stop while Stopped/
    // Stopping is a no-op; Play while Stopping cancels the fade with the
    // same gain envelope. The audio thread completes the two edges.
    enum class TransportState : int { stopped = 0, starting = 1, playing = 2, stopping = 3 };
    bool isPlayingForTest() const { return transportActive(); }
    // v1.33.4 (H3): the stop the app asked for is still running (the
    // fade-out) - the audio thread is the one that ends it.
    bool stopPendingForTest() const { return transportStopping(); }
    TransportState transportStateForTest() const { return transport(); }
    int engineResetCountForTest() const
    {
        return engineResetSerial.load (std::memory_order_relaxed);
    }
    int seekCountForTest() const
    {
        return seekSerial.load (std::memory_order_relaxed);
    }
    int activeVoiceCountForTest() const { return engine.activeVoiceCountForTest(); }
    void startPlaybackForTest() { startPlayback(); }
    void stopPlaybackForTest() { stopPlayback(); }
    void seekPlayheadForTest (double t) { seekPlayhead (t); }
    void clickPlayForTest() { playBtn.onClick(); }
    void clickStopForTest() { stopBtn.onClick(); }
    void injectOscMessageForTest (const juce::OSCMessage& m) { osc.handleMessageForTest (m); }
    void updateExternalScrubForTest (double nowMs) { updateExternalScrub (nowMs); }
    // M6: the audio thread's mailbox. The selftest has no message loop, so
    // the timer that drains the mailbox never ticks: the test drains it by
    // hand, exactly as the timer does.
    void drainAudioMessagesForTest() { drainAudioMessages(); }
    // How many records are waiting in the mailbox (the producer's count
    // minus the consumer's).
    int pendingAudioMessagesForTest() const
    {
        const int w = audioMessageWrite.load (std::memory_order_acquire);
        const int r = audioMessageRead.load (std::memory_order_acquire);
        return (w >= r) ? (w - r) : (w + kAudioMessageSlots - r);
    }
    // The number of records the mailbox has delivered to the message thread.
    int drainedAudioMessagesForTest() const { return audioMessagesDrained; }

    // v1.33.3: the toolbar cards, so the selftest can prove that every
    // toolbar control sits on a card (a wrapped group used to leave the
    // middle of its controls on the bare background).
    int toolbarCardCountForTest() const { return (int) toolbarGroups.size(); }
    juce::Rectangle<int> toolbarCardBoundsForTest (int i) const
    {
        return (i >= 0 && i < (int) toolbarGroups.size())
                 ? toolbarGroups[(size_t) i].area : juce::Rectangle<int>();
    }
    // v1.34.1: a card by its group name, so the layout checks do not depend
    // on where the packing put it.
    juce::Rectangle<int> toolbarCardBoundsForGroupForTest (const juce::String& name) const
    {
        for (auto& c : toolbarGroups)
            if (c.name == name) return c.area;
        return {};
    }
    // The card's place in the toolbar's card list, so the selftest can check
    // the ORDER the cards are in (-1 when the card is not there).
    int toolbarCardIndexForGroupForTest (const juce::String& name) const
    {
        for (int i = 0; i < (int) toolbarGroups.size(); ++i)
            if (toolbarGroups[(size_t) i].name == name) return i;
        return -1;
    }
    juce::Rectangle<int> toolbarBoundsForTest() const { return toolbarBounds; }

    // --- F4 (2026-11-17): the focus views --------------------------------
    // A focus view maximises one panel: the score, the wave editor or the
    // envelope editor. The permanent strip (Menu, Play/Stop, the tool and
    // Restore) stays, every other group and the other editors go, and
    // leaving the focus restores the layout exactly as it was - the panel
    // sizes, the scroll positions and the zoom levels are untouched.
    enum class FocusPanel : int { none = 0, score = 1, wave = 2, env = 3 };
    void setFocusedPanel (FocusPanel p);
    FocusPanel focusedPanelForTest() const { return focusedPanel; }
    bool focusActiveForTest() const { return focusedPanel != FocusPanel::none; }

    void paint(juce::Graphics& g) override;
    void resized() override;
    void timerCallback() override;
    std::uint64_t scoreTimerRepaintRequestCountForTest() const
    { return scoreTimerRepaintRequestCount; }

private:
    // --- construction ---
    // v1.30 (5.3 refactor): the constructor used to be 1400 lines long. It
    // is now one call per group of controls, and each group lives in its
    // own method, in the order the groups appear in the window.
    void buildTransportControls();
    void buildViewToggles();
    void buildAudioOverlay();
    void buildSettingsOverlay();
    void buildClearOverlay();
    void buildLiveControls();
    void buildCombos();
    void buildToolbarControls();
    void buildMaterialControls();
    void buildSieveControls();
    void buildStepControls();
    void buildFrequencyControls();
    void buildArcListPanel();
    void buildMidiControls();
    void buildMaterialTabs();
    void buildPmControls();
    void buildSampleControls();
    void buildLiveInputControls();
    void buildScoreArea();
    void buildEditors();

    // Undo/redo restores the model, not the UI's bank selections. Keep a
    // selected asset selected when the restored piece still owns that id.
    void restoreHistorySelections (int waveId, int envelopeId, int ampTableId,
                                   int sequenceId, int sampleSlotIndex);

    // WP7: publish the one route token that arbitrates the ordinary
    // scrub/freeze routes and the extraction A/B route. The message thread
    // calls this; the audio thread only reads the atomic token.
    void setAudioPreviewRoute (AudioPreviewRoute route);

    // Release the shared token only when the named route still owns it.
    // This keeps one route's cancellation from stealing a route that was
    // claimed after it (for example, a deferred extraction cancellation
    // arriving after a new scrub).
    void releaseAudioPreviewRouteIf (AudioPreviewRoute route);

    // Release one exact token. The deferred lifecycle cancellation uses the
    // extraction generation it captured, so it cannot cancel a newer preview.
    void releaseAudioPreviewRouteTokenIf (std::uint64_t expectedToken);

    // Capture a lifecycle epoch before preparing route state. After taking
    // audioPreviewRouteLock, audioPreviewRouteClaimIsCurrent() decides
    // whether that claim may still be published.
    std::uint64_t audioPreviewRouteEpochForClaim() const;
    bool audioPreviewRouteClaimIsCurrent (std::uint64_t epoch) const;

    // The ordinary scrub/freeze request is published as one immutable
    // versioned record. The message thread owns the source state; the audio
    // thread takes the newest record through the same lock-free handover as
    // the model snapshot, then owns the private transport state for that
    // generation. No sequence of independent atomics can form a mixed record.
    struct OrdinaryPreviewState
    {
        std::uint64_t generation = 0;
        std::uint64_t scrubTransport = 0;
        std::uint64_t freezeTransport = 0;
        std::uint64_t freezePhase = 0;
        bool scrubActive = false;
        double scrubPlayhead = 0.0;
        int scrubRemaining = 0;
        double scrubRate = 1.0;
        bool freezeActive = false;
        double freezePlayhead = 0.0;
        double freezeStopAtMs = 0.0;
        double transitionStartMs = 0.0;
        double transitionEndMs = 0.0;
        std::uint64_t coherenceTag = 0;
    };

    struct OrdinaryPreviewSnapshot : SnapshotBase
    {
        explicit OrdinaryPreviewSnapshot (const OrdinaryPreviewState& s) : state (s) {}
        OrdinaryPreviewState state;
    };

    static std::uint64_t ordinaryPreviewCoherenceTag (
        const OrdinaryPreviewState& state) noexcept;
    OrdinaryPreviewState copyOrdinaryPreviewStateForMessageThread() const noexcept;
    void publishOrdinaryPreviewState (const OrdinaryPreviewState& state);
    void clearOrdinaryPreviewRoutes();
    // Ends an ordinary preview and releases its exact route token. Model
    // replacement and transport start use this so an old request cannot
    // render the replacement piece or resume after Stop.
    void cancelOrdinaryPreviewRoutes();
    bool claimScrubPreviewRoute (double timeSec, double rate);
    bool claimScrubFreezeRoute (double timeSec);
    void updateScrubFreezeStop (double stopAtMs);
    void cancelScrubFreezeRoute();

    // A host preparation/release is a hard boundary for every preview
    // route. The lifecycle epoch is odd while the boundary is active and
    // even between boundaries, so a publisher that captured either side of
    // the boundary is rejected instead of arming a route during preparation.
    // The caller holds audioPreviewLifecycleLock across the whole boundary.
    std::uint64_t beginPreviewRoutesForHostLifecycle();
    void endPreviewRoutesForHostLifecycle();
    void cancelSampleExtractPreviewForHostLifecycle (std::uint64_t generation);
    // Ends every preview route at a host preparation/release boundary.
    void cancelPreviewRoutesForHostLifecycle();
    void closeAudioPreviewCallbackGate();

    // --- F6 (2026-11-17): the view commands and the numeric edit ---------
    // The numeric edit moves the selected point through the same path as a
    // drag, so the undo transaction and the model revision see it.
    void editSelectionTime (double tSec);
    void editSelectionFreq (double hz);
    void refreshPointFields();

    // v1.33.3: the wavetable's shape buttons wear the colour of the wave
    // they make - the same palette the arcs and the wave table use.
    void updateWaveButtonColours();

    // --- the layout ---
    // v1.30 (5.3 refactor): resized() was 460 lines. The flow layout (the
    // rows, the scale fitting, the placing) stays in resized(); the side
    // column, the tab strip and the overlay cards have their own methods.
    void layoutSideColumn (const juce::Rectangle<int>& bounds);
    void layoutOverlays (float scale);

    // v1.33.3: the toolbar's fonts follow the layout's scale factor. The
    // LookAndFeel_V4 derives a button's font from its HEIGHT, which the
    // shrink-to-fit capped - so a small window made the text wrap or clip.
    // Here the fonts scale with the layout, so a control's text is always
    // whole, and the layout can measure the text it needs.
    class UpicLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        float uiScale = 1.0f;

        juce::Font buttonFont() const
        { return withDefaultMetrics (juce::FontOptions (juce::jlimit (8.0f, 16.0f, 16.0f * uiScale))); }
        juce::Font toggleFont() const
        { return withDefaultMetrics (juce::FontOptions (juce::jlimit (8.0f, 15.0f, 15.0f * uiScale))); }

        juce::Font getTextButtonFont (juce::TextButton&, int) override { return buttonFont(); }
        // Paint icons as an addition to the ORIGINAL visible label, never as
        // a replacement. On short buttons use icon+text; on narrow buttons
        // stack a small symbol above the text. When a control is too small
        // for both, the original JUCE text takes priority over the icon.
        void drawButtonText (juce::Graphics& g, juce::TextButton& button,
                             bool highlighted, bool down) override
        {
            const auto* icon = upic::buttonIcons::drawableFor (button);
            if (icon == nullptr)
            {
                if (upic::buttonIcons::singleLineText (button))
                {
                    const auto font = buttonFont();
                    g.setFont (font);
                    g.setColour (button.findColour (button.getToggleState()
                        ? juce::TextButton::textColourOnId : juce::TextButton::textColourOffId));
                    if (! button.isEnabled()) g.setOpacity (0.5f);
                    g.drawFittedText (button.getButtonText(),
                                      button.getLocalBounds().reduced (3, 0),
                                      juce::Justification::centred, 1, 0.55f);
                    return;
                }
                juce::LookAndFeel_V4::drawButtonText (g, button, highlighted, down);
                return;
            }

            const auto bounds = button.getLocalBounds();
            const auto label = button.getButtonText();
            const auto font = buttonFont();
            if (label.isEmpty())
            {
                const float sz = (float) juce::jmin (18, juce::jmin (bounds.getWidth(), bounds.getHeight()) - 4);
                if (sz > 0.0f)
                    icon->drawWithin (g, { ((float) bounds.getWidth() - sz) * 0.5f,
                                            ((float) bounds.getHeight() - sz) * 0.5f, sz, sz },
                                      juce::RectanglePlacement::centred,
                                      button.isEnabled() ? 1.0f : 0.42f);
                return;
            }

            const auto drawLabel = [&] (juce::Rectangle<int> labelBounds, juce::Font labelFont)
            {
                g.setFont (labelFont);
                g.setColour (button.findColour (button.getToggleState()
                    ? juce::TextButton::textColourOnId : juce::TextButton::textColourOffId));
                if (! button.isEnabled()) g.setOpacity (0.5f);
                g.drawFittedText (label, labelBounds, juce::Justification::centred, 1, 0.55f);
            };

            // Prefer horizontal icons when the text fits without shrinking.
            // The estimate errs on the generous side for the variable-width
            // UI font, avoiding unreadable icons+labels in narrow controls.
            const int sideIconSize = juce::jmax (0, juce::jmin (juce::jlimit (10, 17,
                                             juce::roundToInt (16.0f * uiScale)), bounds.getHeight() - 6));
            const int estimatedLabelWidth = juce::roundToInt (
                font.getHeight() * 0.58f * (float) label.length());
            const bool compactPreset = upic::buttonIcons::compactShapeButton (button);
            const bool forceInline = upic::buttonIcons::inlineIcon (button);
            const bool sideBySide = forceInline
                || (! compactPreset
                    && bounds.getWidth() >= estimatedLabelWidth + sideIconSize + 12);

            if (sideBySide && sideIconSize > 0)
            {
                // v1.34.4: the wave and env window's buttons centre the
                // icon+caption block - the icon sits right before the text.
                int iconX = 4;
                juce::Rectangle<int> textArea;
                if (forceInline)
                {
                    const int textW = juce::GlyphArrangement::getStringWidthInt (font, label);
                    const int blockW = juce::jmin (bounds.getWidth() - 4,
                                                  sideIconSize + 3 + textW);
                    iconX = (bounds.getWidth() - blockW) / 2;
                    textArea = juce::Rectangle<int> (iconX + sideIconSize + 3, bounds.getY(),
                                                     juce::jmax (1, blockW - sideIconSize - 3),
                                                     bounds.getHeight());
                }
                else
                {
                    textArea = bounds.withTrimmedLeft (iconX + sideIconSize + 3)
                                       .withTrimmedRight (2);
                }
                const int iconY = (bounds.getHeight() - sideIconSize) / 2;
                icon->drawWithin (g, { (float) iconX, (float) iconY,
                                       (float) sideIconSize, (float) sideIconSize },
                                  juce::RectanglePlacement::centred,
                                  button.isEnabled() ? 1.0f : 0.42f);
                drawLabel (textArea, font);
                return;
            }

            // The waveform/envelope preset row is about 26px high. Even
            // there, show BOTH the miniature actual shape and its original
            // caption (Sine, Saw, Sqr, Tri, Noise, Smooth, Norm, etc.).
            if (bounds.getHeight() >= 19 && bounds.getWidth() >= 16)
            {
                const int topPadding = 1;
                const int iconSize = juce::jlimit (7, 12, (bounds.getHeight() - 4) / 2);
                icon->drawWithin (g, { (float) (bounds.getWidth() - iconSize) * 0.5f,
                                       (float) topPadding, (float) iconSize, (float) iconSize },
                                  juce::RectanglePlacement::centred,
                                  button.isEnabled() ? 1.0f : 0.42f);
                const int labelTop = topPadding + iconSize + 1;
                const auto smallFont = font.withHeight (juce::jlimit (7.0f, 10.0f,
                    (float) (bounds.getHeight() - labelTop) * 0.94f));
                drawLabel (bounds.withTrimmedTop (labelTop).reduced (1, 0), smallFont);
                return;
            }

            // Very small controls retain the readable original text rather
            // than silently becoming pictogram-only buttons. v1.34.3: the
            // caption stays on one line where the user asked for it (the
            // zoom Reset is the visible case) - JUCE's default wraps to 2.
            if (upic::buttonIcons::singleLineText (button))
            {
                drawLabel (button.getLocalBounds().reduced (3, 0), font);
                return;
            }
            juce::LookAndFeel_V4::drawButtonText (g, button, highlighted, down);
        }

        void drawComboBox (juce::Graphics& g, int width, int height,
                           bool isButtonDown, int buttonX, int buttonY,
                           int buttonW, int buttonH, juce::ComboBox& box) override
        {
            juce::LookAndFeel_V4::drawComboBox (g, width, height, isButtonDown,
                                                buttonX, buttonY, buttonW, buttonH, box);
            if (const auto* icon = upic::buttonIcons::toolDrawable (box))
            {
                const float sz = (float) juce::jlimit (10, 17, height - 8);
                icon->drawWithin (g, { 6.0f, (height - sz) * 0.5f, sz, sz },
                                  juce::RectanglePlacement::centred, box.isEnabled() ? 1.0f : 0.4f);
            }
        }

        void positionComboBoxText (juce::ComboBox& box, juce::Label& label) override
        {
            juce::LookAndFeel_V4::positionComboBoxText (box, label);
            if (box.getName() == "toolBox")
                label.setBounds (label.getBounds().withTrimmedLeft (20));
        }
        juce::Font getComboBoxFont (juce::ComboBox&) override { return buttonFont(); }
        juce::Font getLabelFont (juce::Label& l) override
        { return withDefaultMetrics (juce::FontOptions (l.getFont().getHeight() * uiScale)); }

        // v1.34.5: the status line stays on one line. Label's default draw
        // wraps to a second line whenever the label happens to be tall
        // enough, which the shrink-to-fit layout can produce; the status
        // card is measured to that single line instead.
        void drawLabel (juce::Graphics& g, juce::Label& label) override
        {
            if (label.getName() != "statusLab")
            {
                juce::LookAndFeel_V4::drawLabel (g, label);
                return;
            }

            g.fillAll (label.findColour (juce::Label::backgroundColourId));
            if (label.isBeingEdited())
            {
                juce::LookAndFeel_V4::drawLabel (g, label);
                return;
            }

            const auto alpha = label.isEnabled() ? 1.0f : 0.5f;
            const juce::Font font (getLabelFont (label));
            g.setColour (label.findColour (juce::Label::textColourId)
                              .withMultipliedAlpha (alpha));
            g.setFont (font);
            const auto textArea = getLabelBorderSize (label)
                                      .subtractedFrom (label.getLocalBounds());
            g.drawFittedText (label.getText(), textArea,
                              label.getJustificationType(), 1, 0.55f);
        }

        // F11: the knob's horizontal fallback draws its own track and its
        // own value text, so the slider's area is the track's area - the
        // drag and the drawing then agree.
        juce::Slider::SliderLayout getSliderLayout (juce::Slider& slider) override
        {
            if (auto* knob = dynamic_cast<upic::Knob*> (&slider))
                if (knob->isFallback())
                {
                    juce::Slider::SliderLayout layout;
                    layout.sliderBounds = knob->fallbackTrackArea()
                                              .reduced (upic::Knob::kTrackInset, 0);
                    layout.textBoxBounds = {};
                    return layout;
                }

            return juce::LookAndFeel_V4::getSliderLayout (slider);
        }

        // the V4 default, but with the app's scale: the toggle's text then
        // never has to wrap onto a second line
        void drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                               bool highlighted, bool down) override
        {
            const auto font = toggleFont();
            const auto fontSize = font.getHeight();
            const auto tickWidth = fontSize * 1.1f;
            const auto* icon = upic::buttonIcons::drawableFor (button);
            if (icon != nullptr && button.getWidth() >= 34)
            {
                const float sz = juce::jlimit (10.0f, 18.0f, fontSize * 1.04f);
                const float top = ((float) button.getHeight() - sz) * 0.5f;
                const auto accent = button.findColour (juce::ToggleButton::tickColourId);
                // The coloured icon plate is an explicit indicator of the
                // toggle's on/off state, replacing the default tick box.
                g.setColour (accent.withAlpha (button.getToggleState() ? 0.37f : 0.10f));
                g.fillRoundedRectangle ({ 2.0f, top - 2.0f, sz + 5.0f, sz + 4.0f }, 3.0f);
                if (button.getToggleState())
                {
                    g.setColour (accent.withAlpha (0.9f));
                    g.drawRoundedRectangle ({ 2.0f, top - 2.0f, sz + 5.0f, sz + 4.0f }, 3.0f, 1.1f);
                }
                icon->drawWithin (g, { 4.0f, top, sz, sz },
                                  juce::RectanglePlacement::centred,
                                  button.isEnabled() ? 1.0f : 0.42f);
                g.setColour (button.findColour (juce::ToggleButton::textColourId));
                g.setFont (font);
                if (! button.isEnabled()) g.setOpacity (0.5f);
                g.drawFittedText (button.getButtonText(),
                                  button.getLocalBounds().withTrimmedLeft ((int) sz + 11)
                                         .withTrimmedRight (2),
                                  juce::Justification::centredLeft, 1);
                return;
            }
            drawTickBox (g, button, 4.0f, ((float) button.getHeight() - tickWidth) * 0.5f,
                         tickWidth, tickWidth, button.getToggleState(), button.isEnabled(),
                         highlighted, down);
            g.setColour (button.findColour (juce::ToggleButton::textColourId));
            g.setFont (font);
            if (! button.isEnabled()) g.setOpacity (0.5f);
            g.drawFittedText (button.getButtonText(),
                              button.getLocalBounds()
                                     .withTrimmedLeft (juce::roundToInt (tickWidth) + 10)
                                     .withTrimmedRight (2),
                              juce::Justification::centredLeft, 10);
        }
    };
    UpicLookAndFeel appLaf;

    // --- data ---
    std::vector<upic::Waveform> waveforms;
    std::vector<upic::Envelope> envelopes;
    // WP2: the amplitude conversion tables (their own bank).
    std::vector<upic::AmplitudeTable> ampTables;

    // WP4: the performance sequences (piece-level, recorded and replayed by
    // the audio thread's own clock).
    std::vector<upic::PerformanceSequence> sequences;
    // WP6: the mixer channels (model only; engine/UI in later milestones).
    std::vector<upic::Channel> channels;
    int nextChannelId = 1;
    int selChannelId = -1;

    int selSeqId = -1;
    bool seqRecording = false;
    double seqRecordStartMs = 0.0;
    double seqRecordTimeOffset = 0.0;   // replace-tail recordings start at this t
    double seqReplaceFromT = -1.0;      // armed replace-tail point
    double seqOverwriteArmedMs = -1.0;  // two-step overwrite confirmation
    bool seqDecimated = false;          // the recorder thinned the points to fit
    bool seqEditOpen = false;           // the record session owns one undo step
    std::atomic<bool> seqPlayActive { false };
    std::atomic<int> seqActiveId { -1 };
    std::atomic<double> seqClock { 0.0 };

    std::vector<upic::SampleSlot> sampleSlots; // fixed 8 slots, ids 1..8
    std::vector<upic::Page> pages;
    int currentPage = 0;
    int selWave = 0, selEnv = 0, selSlot = 0;
    int drawMatMode = 0;                 // 0 = oscillator, 1 = sample pitch-shift
    double drawRef = upic::kDefaultRefFreq;
    float drawIntensity = 0.8f;

    UpicEngine engine;
    UpicEngine scrubEngine;   // v1.28: dedicated engine for scrub previews
    // WP7: the sample extraction preview has its own engine and transport
    // state. It can never share the score's scrub voice or playhead.
    UpicEngine sampleExtractEngine;
    // The host may prepare on a setup thread while an audio block is still
    // finishing. This gate serialises engine/scratch preparation with the
    // block; the audio side uses a non-blocking try-lock and stays silent
    // while preparation owns the gate.
    juce::CriticalSection audioEnginePreparationLock;
    // A host preparation is published as a generation. The host thread only
    // records the request; the message thread applies it to the engine and
    // publishes the matching generation. The audio callback renders only
    // while the requested and published generations are equal.
    juce::CriticalSection audioPreparationRequestLock;
    std::atomic<std::uint64_t> requestedAudioPreparationGeneration { 0 };
    std::atomic<std::uint64_t> publishedAudioPreparationGeneration { 0 };
    // The message thread publishes how many vocoder voices the current model
    // needs. Host-thread preparation never inspects pages/currentPage.
    std::atomic<int> publishedSampleVocoderVoices { 0 };
    std::atomic<int> publishedLiveVocoderVoices { 0 };
    juce::CriticalSection dataLock;   // message-thread model lock; the audio
                                      // thread never takes it (v1.18)
    double playheadSec = 0.0;         // message thread's view (ScoreEditor)
    // v1.33.4 (L14): the sample rate crosses the thread boundary - the
    // device's prepareToPlay writes it, the audio thread reads it. A plain
    // double was a data race: a torn read is possible, and it is undefined
    // behaviour. It is kept as an atomic count of frames per second: an int
    // is lock-free on every platform, a double is not on a 32-bit one.
    std::atomic<int> audioSampleRateHz { 44100 };
    double audioSampleRate() const { return (double) audioSampleRateHz.load (std::memory_order_relaxed); }
    // the rate the last audio block used (a diagnostic, v1.33.4 / L14)
    std::atomic<int> lastBlockRateHz { 0 };
    double audioPlayRate = 1.0;     // audio-thread view of the direction
    int    seenDirChangeSerial = 0;
    int    dirFadeOutRemaining = 0;
    int    dirFadeInRemaining  = 0;
    // --- F1: the transport state (published to the audio thread) ---
    // The message thread owns the user's transitions; the audio thread reads
    // the state and completes the two edges: Starting -> Playing when the
    // fade-in reaches 1.0, Stopping -> Stopped when the fade-out reaches 0.
    // The compare-exchange in the audio thread means a Play that cancels a
    // stop is never overwritten by the fade's completion.
    std::atomic<int> transportState { (int) TransportState::stopped };
    // v1.33.4 (L15): the piece differs from what was last written
    std::atomic<bool> pieceDirty { false };
    // --- v1.33.4 (L15, part 2): the undo stack (the message thread only) ---
    struct UndoEntry
    {
        upic::PieceModel model;
        juce::int64 bytes = 0;      // the size of the snapshot (the audio is shared)
        juce::String label;
    };
    std::vector<UndoEntry> undoStack, redoStack;
    juce::int64 undoBytes = 0, redoBytes = 0;
    // the snapshot of the edit that is in progress (empty when there is none)
    std::unique_ptr<upic::PieceModel> pendingEdit;
    juce::uint64 pendingRevision = 0;
    juce::String pendingLabel;
    // the bounds: the stack is bounded by the number of steps and by the
    // memory it holds (the oldest steps go first).
    static constexpr int kMaxUndoSteps = 50;
    static constexpr juce::int64 kMaxUndoBytes = 64ll * 1024 * 1024;
    // --- v1.33.4 (L15, part 3): the crash recovery ---
    // when the last recovery snapshot was written, and the model revision it
    // was written from (a snapshot is only worth writing when something
    // changed since the last one)
    juce::uint64 lastRecoveryMs = 0;
    juce::uint64 lastRecoveryRevision = 0;
    inline static std::atomic<bool> recoveryAllowed { true };
    std::atomic<double> playRate { 1.0 };   // +1 forward, -1 backward
    std::atomic<double> prevPlayRate { 1.0 };
    std::atomic<int>    dirChangeSerial { 0 };
    double scrubVelocity = 0.0, scrubTarget = 0.0;
    double lastStopClickMs = -1.0e9;  // v1.27: double-click Stop = rewind
    // v1.33.3: a group wider than its line wraps inside itself, so its card
    // needs one rect per line segment - a single bounding box would leave the
    // middle segment on the bare background and paint over the line gaps.
    struct ToolbarCard
    {
        juce::Rectangle<int> area;
        int colour = 0;
        juce::String name;   // v1.34.1: the group (or "permanent"/"hints")
    };
    std::vector<ToolbarCard> toolbarGroups;
    juce::Rectangle<int> toolbarBounds; // the whole toolbar block (cards + sidebar)
    bool   scrubActive = false;
    bool   scrubAudition = true;            // v1.28: short audio preview while scrubbing
    std::atomic<bool> arcEditing { false }; // an arc is being dragged/drawn
    std::atomic<bool> muteWhileDragging { true };        // skip model publishes while editing
    std::atomic<int> dragSmoothMs { 20 };              // fade time on release
    // WP7: the one authoritative preview-route token. The ordinary scrub and
    // freeze routes and the extraction A/B route can never render together.
    std::atomic<std::uint64_t> audioPreviewRouteToken { makeAudioPreviewRouteToken (
        AudioPreviewRoute::none, 0) };
    // Route publication and host lifecycle cancellation share this lock.
    // The epoch lets a publisher that was waiting when a lifecycle boundary
    // began notice that its claim is stale and refuse to arm a route.
    juce::CriticalSection audioPreviewRouteLock;
    // Serialises overlapping host preparation/release boundaries. The epoch
    // is odd while a boundary is active and even between boundaries.
    juce::CriticalSection audioPreviewLifecycleLock;
    std::atomic<std::uint64_t> audioPreviewLifecycleEpoch { 0 };
    std::atomic<bool> audioPreviewLifecycleCancelling { false };
    // A lifecycle cancellation may have to cross from a host thread to the
    // message thread. This gate keeps a queued callback from touching the
    // component after an off-thread destructor has begun.
    struct AudioPreviewCallbackGate
    {
        std::mutex mutex;
        std::atomic<bool> alive { true };
        // Selftest-only observer: it lets the teardown regression wait until
        // the destructor has closed the gate before it dispatches the queued
        // callback. It lives inside the gate, so the production code carries
        // one allocation, not two.
        std::atomic<bool> closed { false };
    };
    std::shared_ptr<AudioPreviewCallbackGate> audioPreviewCallbackGate =
        std::make_shared<AudioPreviewCallbackGate>();

    // Queue work on the message thread without relying on Component's
    // SafePointer. SafePointer invalidation is not reliable when a plugin
    // host destroys the component on another thread: a queued callback could
    // retain a non-null pointer to freed storage. The shared gate is closed
    // before teardown; a callback either owns the gate while the component
    // is whole or observes the closed gate and does nothing.
    //
    // M6: this path ALLOCATES (callAsync allocates a message for every
    // call), so it must never be used from the audio thread. The audio
    // thread's own hand-off goes through the preallocated mailbox below.
    // The three remaining callers run on the message thread or on the
    // host's setup thread - never on the real-time audio thread - and the
    // assertion catches a violation in the debug build.
    template <typename Callback>
    void postToMessageThread (Callback&& callback)
    {
        jassert (! inAudioCallback);

        auto* const messages = juce::MessageManager::getInstanceWithoutCreating();
        if (messages == nullptr)
            return;

        const auto gate = audioPreviewCallbackGate;
        auto* const component = this;
        messages->callAsync ([gate, component,
                              callback = std::forward<Callback> (callback)]() mutable
        {
            std::lock_guard<std::mutex> lock (gate->mutex);
            if (gate->alive.load (std::memory_order_acquire))
                callback (*component);
        });
    }

    //==============================================================================
    // M6: the audio thread's messages to the message thread.
    //
    // The old path queued a std::function through MessageManager::callAsync,
    // which allocates a message on EVERY call: a malloc on the audio thread
    // at every transport edge, page change and capture hand-off.
    //
    // This is a fixed ring of preallocated records. The audio thread writes
    // one into the next free slot (no allocation, no lock) and the message
    // thread takes the records out in its timer tick. One producer (the
    // audio thread), one consumer (the message thread).
    enum class AudioMessageKind : std::uint8_t
    {
        none,
        stopPlayback,       // the transport reached the end of its fade
        pageChanged,        // the score moved to another page
        finalizeCapture     // a take ended and has to be written to its slot
    };
    struct AudioMessage
    {
        AudioMessageKind kind = AudioMessageKind::none;
        int generation = 0;  // the page epoch (the guard against a late page)
        int page = 0;
    };
    static constexpr int kAudioMessageSlots = 32;
    AudioMessage audioMessages[kAudioMessageSlots] {};
    std::atomic<int> audioMessageWrite { 0 };
    std::atomic<int> audioMessageRead { 0 };
    // How many records the message thread has taken out (the selftest's
    // proof that the hand-off really arrived).
    int audioMessagesDrained = 0;

    // The audio thread's side: the record goes into the next free slot.
    // No allocation, no lock - only the slot and the index move.
    void postAudioMessage (AudioMessageKind kind,
                           int generation = 0,
                           int page = 0) noexcept
    {
        const int write = audioMessageWrite.load (std::memory_order_relaxed);
        const int next = (write + 1) % kAudioMessageSlots;
        if (next == audioMessageRead.load (std::memory_order_acquire))
            return;   // the ring is full - it never is (the message thread drains it)

        AudioMessage& slot = audioMessages[write];
        slot.kind = kind;
        slot.generation = generation;
        slot.page = page;
        audioMessageWrite.store (next, std::memory_order_release);
    }

    // The message thread's side: take the records out and act on them. This
    // runs in the timer tick, so it holds no lock and the component is whole.
    void drainAudioMessages()
    {
        for (;;)
        {
            const int read = audioMessageRead.load (std::memory_order_relaxed);
            if (read == audioMessageWrite.load (std::memory_order_acquire))
                return;

            // The producer only writes a slot the consumer has released, so
            // the record is complete here (the release/acquire pair on the
            // indices is the hand-off).
            const AudioMessage& slot = audioMessages[read];

            switch (slot.kind)
            {
                case AudioMessageKind::stopPlayback:
                    stopPlayback (true);
                    break;

                case AudioMessageKind::pageChanged:
                    // the epoch guard drops a late notification if the user
                    // picked another page meanwhile
                    if (pageEpoch.load (std::memory_order_relaxed) == slot.generation)
                    {
                        currentPage = juce::jlimit (0, (int) pages.size() - 1, slot.page);
                        refreshBoxes();
                        refreshScoreBinding();
                    }
                    break;

                case AudioMessageKind::finalizeCapture:
                    finalizeCapture();
                    break;

                case AudioMessageKind::none:
                    break;
            }

            // The slot is released only after it has been acted on, so the
            // producer can never overwrite a record that is still in use.
            audioMessageRead.store ((read + 1) % kAudioMessageSlots,
                                    std::memory_order_release);
            ++audioMessagesDrained;
        }
    }

    // M6: the marker for the real-time audio thread. The debug build
    // asserts that the allocating hand-off is never used there, and the
    // selftest uses it to prove that the audio path allocates nothing.
    static inline thread_local bool inAudioCallback = false;
    struct AudioCallbackScope
    {
        AudioCallbackScope() noexcept { inAudioCallback = true; }
        ~AudioCallbackScope() noexcept { inAudioCallback = false; }
        JUCE_DECLARE_NON_COPYABLE (AudioCallbackScope)
    };
    // The route and payload presence of the last published extraction
    // snapshot, packed into one atomic word for the selftest. Bit 2 says
    // that the snapshot carried isolated preview material.
    std::atomic<std::uint64_t> publishedSampleExtractSnapshotState { 0 };
    // Selftest-only route transition, applied after snapshot acquisition so
    // the old-snapshot/new-route race is deterministic. The route and its
    // generation offset are packed into one atomic word; all-bits-one means
    // no override.
    std::atomic<std::uint64_t> audioPreviewRouteTestOverride {
        ~std::uint64_t { 0 } };
    // Selftest-only: pause one ordinary route claim after it captures its
    // lifecycle epoch so a host boundary can be placed deterministically
    // between the capture and the route publication.
    std::atomic<bool> audioPreviewRouteClaimPauseRequestedForTest { false };
    std::atomic<bool> audioPreviewRouteClaimPausedFlagForTest { false };
    std::atomic<bool> audioPreviewRouteClaimResumeForTest { false };
    // Selftest-only: lets the callback exercise its null-snapshot path
    // without touching the audio reader's liveSnapshot pointer.
    std::atomic<bool> audioPreviewSkipSnapshotForTest { false };
    // The token that the most recent audio block actually used. It is
    // separate from the published token so a selftest can distinguish the
    // route transition from the route that was live before the block.
    std::atomic<std::uint64_t> audioPreviewRouteTokenSeenForTest { 0 };

    // The ordinary scrub/freeze request is an immutable handover record.
    // The plain source state and these scalar mirrors are written under the
    // route lock; the audio thread reads the coherent record itself.
    OrdinaryPreviewState ordinaryPreviewState;
    std::atomic<std::uint64_t> ordinaryPreviewGeneration { 0 };
    std::atomic<std::uint64_t> ordinaryPreviewScrubTransport { 0 };
    std::atomic<std::uint64_t> ordinaryPreviewFreezeTransport { 0 };
    std::atomic<std::uint64_t> ordinaryPreviewFreezePhase { 0 };
    SnapshotHandover<OrdinaryPreviewSnapshot> ordinaryPreviewSnapshots;
    OrdinaryPreviewSnapshot* liveOrdinaryPreviewSnapshot = nullptr; // audio thread
    std::atomic<std::uint64_t> ordinaryPreviewCoherenceFailureCount { 0 };

    // WP7: the extraction A/B preview's private transport. The message
    // thread owns the route request and publishes it with the immutable
    // material; the audio thread owns the playhead and remaining count after
    // it has adopted a generation. The atomic route token arbitrates this
    // route against the ordinary scrub and freeze routes.
    SampleExtractPreviewState sampleExtractPreviewState;
    // The message thread owns the state above. This atomic mirror lets a
    // host-thread lifecycle request remember the exact extraction generation
    // it must cancel without reading message-thread-only data.
    std::atomic<std::uint64_t> sampleExtractPreviewGenerationPublished { 0 };

    // A message-thread-owned copy of the last published extraction preview.
    // The audio thread's `liveSnapshot` pointer is deliberately never read
    // from the message thread: the reader may retire and free that snapshot
    // concurrently. The selftest compares against this immutable copy.
    struct PublishedSampleExtractPreview
    {
        SampleExtractPreviewState state;
        std::shared_ptr<const upic::Page> page;
        std::vector<upic::SampleSlot> slots;
        std::vector<upic::Waveform> waves;
        std::vector<upic::Envelope> envelopes;
    };
    PublishedSampleExtractPreview publishedSampleExtractPreview;
    uint64_t seenSampleExtractPreviewGeneration = 0;  // audio thread
    double sampleExtractPreviewPlayhead = 0.0;        // audio thread
    int sampleExtractPreviewRemaining = 0;            // audio thread

    // Audio-thread-only ordinary preview transport. The message thread
    // publishes a new transport generation; the audio thread adopts it at a
    // block boundary and updates only these private fields afterwards.
    std::uint64_t seenScrubPreviewTransport = 0;
    std::uint64_t seenFreezeTransport = 0;
    std::uint64_t seenFreezePhase = 0;
    std::uint64_t seenOrdinaryPreviewGeneration = 0;
    std::uint64_t audioFreezeGeneration = 0;
    double audioScrubPreviewPlayhead = 0.0;
    int audioScrubPreviewRemaining = 0;
    bool audioScrubPreviewActive = false;
    double audioScrubRate = 1.0;
    bool audioFreezeActive = false;
    bool audioFreezeExpired = false;
    double audioFreezeStopAtMs = 0.0;

    std::atomic<int> scrubPreviewLen { 0 }; // samples; prepared on the host thread
    double lastScrubT = 0.0;
    double lastScrubMs = 0.0;
    int scrubCrossMs = 20;
    // v1.33.4 (L14): the tail length is written by the slider (the message
    // thread) and read by the audio thread (the freeze fade). A plain int
    // was a data race.
    std::atomic<int> scrubTailMs { 30 };
    int scrubGrainMs = 40;                 // freeze-hold grain size
    int sampleGrainMs = 40;                // granular playback grain size
    int liveGrainMs = 40;                  // v1.30: granular grain size for LIVE arcs
    bool loopPage = true;
    std::atomic<float> masterGain { 0.8f };

    // --- v1.18 (wave 15): the lock-free model handover ---
    // The message thread builds a ModelSnapshot (30 Hz timer, plus right
    // after a load / capture / sample change) and publishes it; the audio
    // thread renders from the snapshot it last took and never locks.
    SnapshotHandover<ModelSnapshot> snapshots;
    ModelSnapshot* liveSnapshot = nullptr;          // audio thread only

    // --- v1.33.4 (M28): the worker thread ---
    // The job that is running and the thread itself (one job at a time).
    upic::JobRunner jobs;
    std::atomic<int> pageEpoch { 0 };               // message -> audio
    int seenPageEpoch = -1;                         // audio
    int audioPage = 0;                              // audio thread's page
    double audioPlayhead = 0.0;                     // audio thread's playhead
    std::atomic<double> seekTo { 0.0 };             // message -> audio
    std::atomic<int> seekSerial { 0 };
    int seenSeekSerial = 0;                         // audio
    std::atomic<double> playheadPublished { 0.0 };  // audio -> UI display
    std::atomic<bool> playheadAtEnd { false };      // the piece ran to its end
    std::atomic<int> engineResetSerial { 0 };       // message -> audio (Play)
    int seenEngineResetSerial = 0;                  // audio

    // --- v1.20 (wave 18): the live reverse ---
    // Two buffers of the maximum duration: one is captured (the write head
    // moves BACKWARDS, so its content is mirrored in time - reading it
    // forward plays it backwards), the other is the frozen segment the
    // shifter reads. When the capture is full the two swap roles, so the
    // capture never stops and nothing is ever copied (no audio-thread
    // spike).
    //
    // Ownership: the message thread owns the settings (the duration, the on
    // / off switch) and only ever *asks*; the audio thread owns the buffers,
    // the heads and the indices. The buffers are allocated once (at the
    // maximum duration) - the message thread never reallocates them while
    // the audio thread may be reading.
    juce::AudioBuffer<float> revBuf[2];
    std::atomic<bool> revLiveOn { false };
    std::atomic<int> revBufFrames { 0 };   // the chosen duration in frames
    std::atomic<bool> revRestart { false }; // the audio thread resets its state
    double revBufSec = 1.0;                // the message thread's duration
    int revCapIdx = 0;                     // the buffer being captured (audio)
    int revPlayIdx = 1;                    // the buffer being played (audio)
    int revCapHead = 0;                    // the capture write position (audio)
    long long revCapCount = 0;             // the frames captured so far (audio)
    int revPlayHead = 0;                   // the playback read position (audio)

    // --- v1.15: click-free output ---
    // The score renders into its own buffer, so a block that cannot be
    // rendered (the UI thread holds the model lock, or the piece ended) can
    // be faded out instead of cut - a hard cut at a block boundary is a
    // click, and it does not care how big the host's buffer is.
    // The gains are smoothed per sample for the same reason: a step in a
    // gain (a slider move, host automation) is a click.
    juce::AudioBuffer<float> scoreBuf, freezeBuf;
    // WP7: the extraction preview never borrows the score or freeze scratch.
    juce::AudioBuffer<float> sampleExtractBuf;
    float scoreGain = 1.0f;   // the score's fade gain (audio thread)
    float scoreTail = 0.0f;   // the score's last sample (for the fade-out)
    float masterSmoothed = 0.8f;
    float inGainSmoothed = 0.8f;
    static constexpr int kScoreFadeSamples = 96; // ~2 ms at 48 kHz
    static constexpr int kDirCrossfadeSamples = 960; // ~20 ms at 48 kHz
    // scrub smoothing (first-guess; needs real-controller validation)
    static constexpr double kScrubSmoothOld = 0.7;
    static constexpr double kScrubSmoothNew = 0.3;
    static constexpr double kScrubTargetDecay = 0.6;
    static constexpr double kScrubHysteresis  = 0.05;
    static constexpr float kGainSmooth = 0.001f;  // ~17 ms time constant

    // The model can change under the audio thread (a page change, a loaded
    // sample, a pitch-mode switch). Those changes replace the sound that is
    // playing, which is a step - a click - so the message thread bumps this
    // counter and the audio thread fades across the change.
    std::atomic<int> modelEpoch { 0 };
    int seenModelEpoch = 0;   // audio thread

    // v1.33.4 (M22): the model revision. It moves whenever the model
    // changes (markModelChanged), and the status timer publishes a snapshot
    // only when it moved - the timer used to deep-copy the whole model 30
    // times a second, even while nothing changed.
    std::atomic<uint64_t> modelRevision { 0 };
    uint64_t lastPublishedRevision = 0;   // message thread
    uint64_t lastModelPublishMs = 0;      // message thread: the safety-net publish
    std::atomic<int> snapshotPublishCount { 0 };

    // --- v1.1 piece state ---
    bool seqPages = false;              // page sequencer: cycle all pages while looping
    bool recordPressure = false;        // pen pressure -> per-point intensity
    bool sieveOn = false;
    int sieveM = 12;
    std::vector<int> sieveR { 0 };
    // M4: the tuning the piece is drawn in (12-tone equal temperament by
    // default). The arcs hold frequencies, so the tuning does not change
    // what is played - it changes what the drawing snaps to, and it travels
    // with the piece so the piece is edited the way it was drawn.
    upic::Tuning tuning;
    juce::String flashMsg;              // transient status message (timer shows it)
    unsigned int flashUntilMs = 0;

    // --- v1.2 piece state (magnetic sieves, UPISketch-style) ---
    double stickiness = 1.0;            // 0..1 snap strength ("Stickiness" slider)
    double timeGrid = 0.0;              // time grid in divisions/sec (0 = off)

    // --- F1: one click-free gain envelope for the transport's two edges ---
    // 30 ms, the length the stop fade has always had. The page-end fade uses
    // the same constant. The envelope state is audio-thread only: the
    // message thread publishes the state, the audio thread counts the ramp.
    static constexpr double kStopFadeSec = 0.03;
    float transportGain = 0.0f;       // the gain the last sample used
    float transportRampFrom = 0.0f;   // the edge the current ramp started at
    float transportRampTo = 0.0f;
    int transportRampPos = 0;
    int transportRampTotal = 0;       // 0 = no ramp pending
    int transportSeenState = (int) TransportState::stopped;

    int drawSampleId = 1;               // sample slot of the current draw voice (set by pushVoice)

    // --- v1.4 live input: monitor + capture takes into sample slots ---
    // No live-gate voice: takes become ordinary sample material (varispeed,
    // stems, save all work unchanged). Audio thread touches only atomics +
    // the preallocated buffers; slot install happens on the message thread.
    juce::ToggleButton monBtn{ "Mon" };
    juce::TextButton capBtn{ "Capture" };
    // v1.31 (U4): the UPIC's wave page could be digitised from a
    // recording. This turns the selected slot into a wavetable.
    juce::TextButton waveFromSlotBtn{ "Slot -> Wave" };
    // WP7: the cycle-aware extraction panel (the old Slot -> Wave above
    // still digitises the whole take).
    juce::TextButton sampleExtractBtn{ "Extract" };
    // F11 (2026-11-18): the toolbar's continuous amounts are knobs (a
    // rotary slider). The OSC port fields stay horizontal sliders - they
    // live in the settings overlay, not in the toolbar.
    upic::Knob inGainSlider;
    juce::Label inGainLab{ {}, "In" };
    bool inputEnabled = false;
    std::atomic<float> inputGain{ 0.8f };
    std::atomic<bool> monitoring{ false };
    std::atomic<bool> capturing{ false };
    std::atomic<bool> capStopRequested{ false };
    std::atomic<bool> capReady{ false };
    std::atomic<bool> capDiscard{ false };
    std::atomic<bool> capAbortPending{ false };
    std::atomic<int> capStopReason{ 0 }; // 1 user, 2 full, 3 input lost, 4 device changed
    std::atomic<int> capPos{ 0 };
    std::atomic<int> numLiveInputs{ 0 };
    // v1.33.4 (M24): how many channels are written out. The standalone app
    // always writes two; a plugin host can ask for fewer (mono out). A host
    // layout can also have more INPUT channels than output ones (stereo in,
    // mono out), and the extra input channels may be read-only memory - so
    // only the output channels are cleared and written.
    std::atomic<int> outChannels{ 2 };
    int capMax = 0, capFinalCount = 0, capFinalReason = 0;
    double capRate = 44100.0;
    juce::AudioBuffer<float> capBuf;    // audio thread writes, message thread reads after handoff
    // M6: the per-block input copy (read pre-clear). It is sized on the
    // message thread (prepareAudioBuffers) for the largest block a host may
    // send - the tap used to grow it inside the audio callback, which is a
    // malloc on the audio thread.
    juce::AudioBuffer<float> inScratch;
    // How many samples of inScratch the last tap wrote (the selftest reads
    // the peak of the LAST block, not of the whole prepared buffer).
    std::atomic<int> inScratchUsed { 0 };
    static constexpr double kMaxCaptureSec = 30.0;

    // --- v1.5 live pitch-follow: input ring read by mode-2 (live input) arcs ---
    // tapLiveInput writes one block per callback; the engine reads behind the
    // write head (granular shifter lag) in the same callback. Audio-thread
    // state only; the ring vectors are (re)allocated in prepareToPlay.
    std::vector<float> liveRingA, liveRingB;
    int liveRingSize = 0;
    long long liveWritePos = 0;  // absolute frames written
    bool liveTapActive = false;  // input channels present this callback
    static constexpr double kLiveRingSec = 2.0;

    // --- UI: transport ---
    juce::TextButton playBtn{ "Play" }, stopBtn{ "Stop" };
    juce::TextButton saveBtn{ "Save" }, loadBtn{ "Load" }, exportBtn{ "Render WAV" };
    juce::TextButton stemsBtn{ "Stems" };
    juce::TextButton clearBtn{ "Clear" };
    juce::TextButton menuBtn{ "File" };
    juce::TextButton audioBtn{ "Audio" };
    juce::TextButton settingsBtn{ "Settings" };
    juce::ToggleButton loopBtn{ "Loop" }, seqBtn{ "Seq" }, revPlayBtn{ "Rev" }, pressBtn{ "Pressure" }, scrubBtn{ "Scrub" };
    // scrub audition controls
    juce::Label scrubLenLab{ {}, "Scrub len" }, scrubCrossLab{ {}, "Crossfade" }, scrubTailLab{ {}, "Release tail" };
    juce::Label scrubGrainLab{ {}, "Hold grain" };
    upic::Knob scrubLenSlider, scrubCrossSlider, scrubTailSlider, scrubGrainSlider;
    juce::Label grainLab{ {}, "Grain" };
    upic::Knob grainSlider;

    // drag-edit smoothing controls
    juce::ToggleButton muteDragBtn{ "Mute drag" };
    juce::Label dragSmoothLab{ {}, "Smooth" };
    upic::Knob dragSmoothSlider;

    juce::ComboBox pageBox, toolBox, waveBox, envBox, waveEditBox, envEditBox, pmIndexEnvBox, pmPresetBox, pmOpsBox;
    juce::TextButton pmImportBtn{ "Import" }, pmExportBtn{ "Export" };
    juce::TextButton pageAddBtn{ "+" }, pageDupBtn{ "Dup" }, pageDelBtn{ "-" };
    upic::Knob durSlider, masterSlider, intenSlider, pmRatioSlider, pmIndexSlider, pmFeedbackSlider, tempoSlider;
    juce::Label durLab{ {}, "Dur" }, masterLab{ {}, "Master" }, intenLab{ {}, "Inten" };
    juce::Label timeLab, statusLab;
    // v1.34.5: the status card is measured to its text, so a materially
    // different status string re-flows the cards once (async, coalesced).
    bool statusLayoutPending = false;
    static constexpr int kStatusMinWidthDp = 220;

    juce::ToggleButton snapBtn{ "Snap" };
    // v1.8 one strip: each material is a tab AND its own canvas layer
    // (Osc = mode 0, Sample = mode 1, Live = mode 2, Hz grid)
    // v1.7 view toggles: bottom editors + instruction hints (right end of
    // the same strip)
    juce::TextButton waveTog{ "Wave" }, envTog{ "Env" }, hintsTog{ "Hints" };
    bool showWaveEd = true, showEnvEd = true, showHints = true;

    // F5: the fold state per group (session state) and the strip that keeps
    // the essential controls reachable at every level.
    std::map<juce::String, GroupLevel> groupLevels;
    std::map<juce::String, std::unique_ptr<juce::ToggleButton>> groupToggles;
    // The controls a fold level hid, so the next layout pass can restore
    // them before the tab visibility rules run again.
    std::vector<juce::Component*> foldHidden;
    juce::TextButton restoreGroupsBtn{ "Restore" };
    // F4: the focus view (the maximised panel) and the buttons that enter
    // and leave it. The focus is session state, never piece state.
    FocusPanel focusedPanel = FocusPanel::none;
    juce::TextButton scoreFocusBtn{ "Focus" }, waveFocusBtn{ "Focus" },
                      envFocusBtn{ "Focus" };
    // F6: the score's view bar (the zoom commands, the readout and the
    // numeric edit of the selected point).
    ScoreViewBar viewBar;
    void updateFocusButtons();
    juce::Rectangle<int> permanentStripBounds;
    int toolbarRows = 0;
    static bool sessionSettingsPersistent;
    juce::ToggleButton* ensureGroupToggle (const juce::String& group);
    void saveSessionSettings() const;
    void loadSessionSettings();

    // v1.7 audio settings: an in-app overlay, since Android has no floating
    // dialog windows (a DialogWindow there has no title bar and no close
    // button, so the audio settings could never be dismissed).
    // v1.30 (5.3 refactor): the overlay type lives in OverlayPanels.h.
    AudioOverlay audioOverlay;
    std::unique_ptr<juce::AudioDeviceSelectorComponent> audioSelector;
    juce::TextButton audioOkBtn{ "OK" };

    // v1.30: MIDI + OSC live in their own settings overlay. The audio overlay
    // keeps only the device selector (UPIC-56), and the phone controller's
    // endpoints are configurable here instead of being compile-time constants.
    AudioOverlay settingsOverlay;
    juce::TextButton settingsOkBtn{ "OK" }, oscApplyBtn{ "Apply" };
    juce::Label midiSectionLab{ {}, "MIDI" }, oscSectionLab{ {}, "OSC" };
    juce::Label oscStatusLab{ {}, "OSC starting..." };
    juce::Label oscPortLab{ {}, "UDP port" }, oscGroupLab{ {}, "Group" }, oscMcPortLab{ {}, "M-port" };
    juce::Slider oscPortSlider, oscMcPortSlider;
    juce::TextEditor oscGroupEdit;
    juce::ToggleButton oscMcBtn{ "Multicast" };
    juce::ToggleButton oscOnBtn{ "OSC on" };

    // v1.31 (U1): the polyagogy - the arc's own wave can also be a control
    // signal (an amplitude LFO or a frequency LFO). These live on the Osc
    // tab's material row and apply to the selected arcs.
    juce::ComboBox modUseBox;
    upic::Knob modRateSlider, modDepthSlider;
    juce::Label modUseLab{ {}, "Wave as" }, modRateLab{ {}, "Rate" },
              modDepthLab{ {}, "Depth" };

    // v1.32: the discrete frequency space - the UPIC's "discrete/non-
    // discrete" function. The arc's sounding pitch is moved through a
    // temperament of n equal divisions per octave, so a glissando is heard
    // as a staircase of discrete steps. The sieve snaps the DRAWN points;
    // this snaps the pitch that PLAYS.
    //
    // It lives on the voice row (visible in every tab) because it belongs
    // to the arc's pitch, not to one material, and it applies to the
    // selected arcs.
    juce::ToggleButton stepBtn{ "Stepped" };
    upic::Knob stepDivSlider;
    juce::Label stepDivLab{ {}, "Div/oct" };

    // v1.33: the frequency spaces (the UPIC's four frequency tables). The
    // PAGE owns the four spaces; an arc names the one it is played in, the
    // way it names its wave or its envelope.
    juce::ComboBox spaceBox;          // the arc's space
    juce::ComboBox spaceDefBox[4];    // the page's four spaces
    juce::Label spaceDefLab[4];
    juce::Label spaceLab{ {}, "Space" };
    // WP1: draw the table of the space selected above.
    juce::TextButton spaceTableBtn{ "Table..." };

    // WP2: the amplitude conversion tables (the bank the arc combo names).
    juce::ComboBox ampTableBox;
    juce::Label ampTableLab{ {}, "Amp" };
    juce::TextButton ampTableBtn{ "Tables..." };
    AmpTableEditor ampTableEd;
    int selAmpTableId = -1;

    // WP3: the arc groups (non-destructive, per page).
    juce::TextButton groupBtn{ "Groups..." };

    // WP5: the independent modulating arc.
    juce::Label arcModLab{ {}, "Mod" }, arcModTgtLab{ {}, "Tgt" }, arcModDepthLab{ {}, "Depth" };
    juce::ComboBox arcModBox, arcModTgtBox;
    juce::Slider arcModSlider;
    bool modLevelsEditing = false;

    // WP4: the performance sequences.
    juce::Label seqLab{ {}, "Seq" };

    // --- WP6.4: the mixer UI (the channel model is WP6.1) ---
    // NOTE: WP7 adds its library/extraction controls in its own marked
    // block below; keep edits inside these markers.
    juce::Label channelLab{ {}, "Ch" };
    juce::ComboBox channelBox;
    juce::TextButton channelBtn{ "Mix..." };
    std::unique_ptr<ChannelPanel> channelPanel;
    bool channelBoxReady = false;
    bool channelBoxRefreshing = false;
    // true while a channel-gain DRAG is open: the gesture owns one undo
    // transaction, so the slider's per-tick notifications do not each push
    // an undo step (and a whole model copy).
    bool channelGainEditing = false;
    // v1.36: true while refreshBoxes() repopulates the controls. A combo
    // change caused by that refresh must not edit the model or begin an
    // undo transaction - a stroke-end refresh would otherwise apply the
    // previous toolbar selection to the arc that was just drawn.
    bool refreshingControls = false;
    double lastScoreRepaintPlayhead = -1.0;   // v1.36: idle paint gate
    std::uint64_t scoreTimerRepaintRequestCount = 0; // idle-gate regression
    juce::String lastStatusText;              // v1.36: status repaint gate
    int timerHzNow = 30;                      // v1.36: idle rate
    uint64_t lastStatusLayoutMs = 0;          // v1.36: relayout cooldown
    juce::String lastTimeText;                // v1.36: clock label gate
    // --- end WP6.4 ---


    juce::ComboBox seqBox;

    juce::TextButton seqRecBtn{ "Rec" }, seqPlayBtn{ "Play" },
                     seqLoopBtn{ "Loop" }, seqEditBtn{ "View" };
    SequencePanel seqPanel;
    GroupPanel groupPanel;
    int selGroupId = -1;
    bool groupLevelsEditing = false;

    // WP1: the in-app frequency-table editor (an overlay: Android has no
    // closable dialog windows).
    FreqTableEditor freqTableEd;
    int freqTablePage = -1;
    int freqTableSpace = -1;
    // The invalid user-library files, kept per asset kind so refreshing one
    // healthy library cannot hide a refusal reported by another. The global
    // text is the visible summary of the union.
    std::map<upic::UserAssetKind, juce::StringArray> userLibraryFailuresByKind;
    juce::String lastUserLibraryFailureText;

    // v1.33: the page's ambitus - the interval its vertical axis covers
    // ("the vertical axis could correspond to any interval", Mache).
    juce::ComboBox ambitusBox;
    juce::Label ambitusLab{ {}, "Ambitus" };

    // v1.33: the page's acceleration - a tempo sweep across the page.
    upic::Knob warpSlider;
    juce::Label warpLab{ {}, "Accel" };

    // v1.27: Clear is destructive, so it asks first. An in-app overlay keeps
    // this working on Android, where floating dialogs cannot be dismissed.
    // v1.30 (5.3 refactor): the overlay type lives in OverlayPanels.h.
    ClearOverlay clearOverlay;
    juce::TextButton clearConfirmBtn{ "Clear page" }, clearCancelBtn{ "Cancel" };
    // v1.9: live pitch algorithm for LIVE-tab arcs (session-only setting)
    juce::ComboBox livePitchBox;
    juce::Label livePitchLab{ {}, "Live pitch" };

    // v1.20 (wave 18): the live reverse - the microphone's last N seconds
    // played backwards. N (the buffer duration) is the user's choice.
    juce::Label liveRevLab{ {}, "Rev len" };
    juce::ComboBox liveRevLenBox;
    juce::TextButton liveRevBtn{ "Rev" };

    // v1.30: the LIVE tab's granular grain size (the same 5-500 ms range as
    // the SAMPLE tab's Granular control). It only affects the granular live
    // pitch mode; Tape and Phase vocoder ignore it.
    juce::Label liveGrainLab{ {}, "Grain" };
    upic::Knob liveGrainSlider;

    // --- UI: material (sample pitch-shift) row ---
    juce::ComboBox sampleBox;
    juce::TextButton loadSampleBtn{ "Load sample" };
    // v1.19 (wave 17): the selected slot plays backwards. Session-only (the
    // piece format is untouched), like the pitch modes and the grid.
    juce::TextButton revBtn{ "Rev" };
    upic::Knob refSlider;
    juce::Label slotLab{ {}, "Slot" }, refLab{ {}, "Ref" }, matHintLab;
    // v1.10: how SAMPLE-tab arcs transpose the slot (session-only, like the
    // live pitch mode): varispeed (the original behaviour) stays the default
    juce::ComboBox samplePitchBox;
    juce::Label samplePitchLab{ {}, "Pitch" };

    // M5: the slot's level and the material's own edits. The level is the
    // user's knob (it changes the sound, so it travels with the piece); the
    // three buttons edit the material itself - the normalise gain, the
    // fades and the trim (the trim is dragged in the material view).
    upic::Knob levelSlider;
    juce::Label levelLab{ {}, "Level" };
    juce::TextButton normMatBtn{ "Norm" }, fadeMatBtn{ "Fade" }, resetMatBtn{ "Reset" };

    // v1.8 the one tab strip (replaces the Material dropdown AND the old
    // Score / Live pitch tabs): each material is its own tab + canvas layer
    // - Osc (wavetable), Sample (slots + capture), Live (mic)
    juce::TextButton matOscTog{ "Osc" }, matSampleTog{ "Sample" }, matLiveTog{ "Live" }, matPmTog{ "PM" };

    // v1.21 (wave 19): the arc list - the score's inventory on the right,
    // with the per-arc controls (the Rev box and the mode dropdown). It is a
    // view: the visibility is session state.
    juce::TextButton arcListBtn{ "Arcs" };
    ArcListPanel arcListPanel;
    bool showArcList = false;
    bool arcListDirty = true;   // the rows have to be rebuilt
    int selectedArcId = -1;    // the arc the panel (and the canvas) point at
    std::vector<int> lastArcSelection; // canvas selection the panel last showed

    // v1.23 (wave 20): the MIDI input foundation - the device list, the
    // activity monitor and the learn (in the audio settings overlay).
    MidiHub midi;
    juce::ComboBox midiDevBox;
    juce::StringArray midiDeviceIds;   // the identifier of each combo box item (v1.33.4 / H9)
    juce::Label midiDevLab{ {}, "MIDI in" };
    juce::Label midiActLab{ {}, "no MIDI yet" };
    juce::TextButton midiLearnGain{ "Learn" }, midiLearnInt{ "Learn" }, midiLearnScrub{ "Learn" }, midiLearnTransport{ "Learn" };
    juce::Label midiBindGainLab{ {}, "-" }, midiBindIntLab{ {}, "-" }, midiBindScrubLab{ {}, "-" }, midiBindTransportLab{ {}, "-" };
    juce::Label midiGainLab{ {}, "Master gain" }, midiIntLab{ {}, "Intensity" }, midiScrubLab{ {}, "Scrub" }, midiTransportLab{ {}, "Transport" };

    // v1.29: the OSC scrub receiver. MobMuPlat (or any OSC sender) moves the
    // playhead with /upic/scrub <0..1> on UDP 9000.
    // v1.30 (5.3 refactor): the receiver and its endpoints live in
    // OscScrubReceiver; this class keeps the scrub gesture itself.
    // The receiver is constructed with *this as its listener (see the
    // constructor's initialiser list).
    OscScrubReceiver osc;
    bool externalScrubActive = false;
    bool externalScrubFrozen = false;
    double externalScrubLastT = 0.0;
    double lastExternalScrubMs = 0.0;
    bool oscAnnounced = false;

    // --- UI: sieve quantizer (same row as material) ---
    juce::ToggleButton sieveBtn{ "Sieve" };
    juce::TextEditor sieveMEdit, sieveREdit;

    // --- UI: v1.2 magnetic-sieve row (preset library, stickiness, time grid,
    //     procedural arc generators) + shortcut/wheel hint line ---
    juce::ComboBox sievePresetBox, gridBox, genBox;
    upic::Knob stickSlider;
    juce::Label pmRatioLab{ {}, "Ratio" }, pmIndexLab{ {}, "Index" }, pmIndexEnvLab{ {}, "IdxEnv" }, pmFeedbackLab{ {}, "Fdbk" }, pmPresetLab{ {}, "Preset" }, pmOpsLab{ {}, "Ops" }, tempoLab{ {}, "BPM" }, stickLab{ {}, "Stick (global)" }, gridLab{ {}, "T-grid (global)" }, sieveMLab{ {}, "m" }, sieveRLab{ {}, "R" };
    juce::Label kbdHintLab;

    // --- UI: editors ---
    ScoreEditor score;
    WaveformEditor waveEd;
    EnvelopeEditor envEd;
    // F2/F3: the two bank managers. They own the placement of the editor
    // selectors (waveEditBox/envEditBox) and the bank commands.
    LibraryManager waveLib { "wave" }, envLib { "env" };
    // WP7: the sample extraction panel is constructed only when it is first
    // opened. WP6's mixer panel overflowed the stack when it was built and
    // torn down in the selftest, so the lazy construction is deliberate.
    std::unique_ptr<SampleExtractPanel> sampleExtractPanel;
    juce::TextButton wSine{ "Sine" }, wSaw{ "Saw" }, wSqr{ "Sqr" }, wTri{ "Tri" }, wNoise{ "Noise" }, wSmooth{ "Smooth" }, wNorm{ "Norm" };
    juce::TextButton eFlat{ "Flat" }, ePerc{ "Perc" }, eSwell{ "Swell" }, eGate{ "Gate" }, eStr{ "Strings" };
    juce::TextButton assignBtn{ "Assign to sel." }, delArcBtn{ "Del sel." }, muteArcBtn{ "Mute sel." };
    // v1.34.4: the arc commands the canvas context menu had (Duplicate,
    // Select all) are buttons in the Voice section as well.
    juce::TextButton dupArcBtn{ "Duplicate" }, selectAllBtn{ "Select all" };
    juce::Label voiceLab, waveLab{ {}, "Wave" }, envLab{ {}, "Env" }, toolLab{ {}, "Tool" };

    upic::Page& curPage();
    const upic::Page& curPage() const;
    void refreshBoxes();
    void refreshScoreBinding();
    void updateStatus();
    void publishModelSnapshot();      // v1.18: message -> audio handover
    // WP7: the A/B preview's isolated page and material. It is built on the
    // message thread into the snapshot; the audio thread only reads it.
    void addSampleExtractPreview (ModelSnapshot& snap);
    // Starts (or restarts) the extraction preview's private transport.
    void restartSampleExtractPreview();
    // The dedicated audio-thread renderer for the extraction preview. It
    // reads only the isolated snapshot material, never the score's slots.
    void renderSampleExtractPreview (const ModelSnapshot& snap, AudioBlock& b, double previewGain);
    // v1.33.4 (M21): prepare the vocoder's working memory for the page, on
    // the message thread, before the audio thread can need it
    void prepareVocodersIfNeeded (int sampleMode, int liveMode);
    // Applies one requested host preparation on the message thread and
    // publishes its generation. It never reads the model from a host thread.
    void applyAudioPreparation (std::uint64_t generation,
                                int samplesPerBlockExpected,
                                double sampleRate);
    // Invalidates a pending preparation (a release, or a newer request).
    void invalidateAudioPreparation();
    // Reapplies the message thread's published vocoder requirements after a
    // preparation changed the sample rate. The caller owns the engine gate.
    void preparePublishedVocoderMemory();
    void seekPlayhead(double t);      // message: move the audio playhead
    void bumpPageEpoch();             // message: the audio adopts the page
    void requestEngineReset();        // message: drop voices on the next block
    double displayPlayhead() const;   // the playhead the UI shows
    // F1: the state and the three questions the rest of the code asks of it.
    // `active` includes Stopping: the audio thread is still rendering the
    // fade, and the playhead is still the audio thread's.
    TransportState transport() const
    {
        return (TransportState) transportState.load (std::memory_order_relaxed);
    }
    bool transportActive() const { return transport() != TransportState::stopped; }
    bool transportStopping() const { return transport() == TransportState::stopping; }
    void pushVoice();                 // UI -> ScoreEditor current voice
    bool prepareWaveEdit();           // v1.27: fork the wavetable for a selection
    // F3 (2026-11-17): fork the selected arcs' envelope when it is shared.
    // `forked` says whether a copy was made; false is returned only when the
    // bank is full and the edit has to be cancelled.
    bool forkEnvelopeForSelection (bool& forked);
    int waveUseCount (int id) const;
    int envelopeUseCount (int id) const;
    void refreshLibraryBoxes();       // the two manager rows (names + use counts)
    // WP7: the user library's rows. The disk is read only for the requested
    // kind when the source switch asks for it, not on every model refresh.
    void refreshUserLibraryBoxes (upic::UserAssetKind kind);
    void afterLibraryChange();        // refresh the UI and publish the model
    void syncControlsToArc(int arcId); // load an arc into the toolbar
    void updateSampleView();
    void updateRevButton();       // v1.19: the Reverse button follows the slot
    // M5: the material's own controls. `editMaterial` does one of the
    // three edits (normalise, fade, reset); the buttons follow the slot
    // (they are off when the slot has no material).
    void updateMaterialButtons();
    void editMaterial (int what);
    // M5: the Sample tab's Ref is the SLOT's (the material's base pitch),
    // so the Ref slider, the grid and the new arcs all follow it.
    void syncRefToSlot();
    void updateRevBuffers();      // v1.20: (re)allocate the live reverse buffers
    void rebuildArcList();        // v1.21: rebuild the panel's rows from the model
    void handleMidi();            // v1.23: the MIDI messages (message thread)
    void handleMidiActivity (const MidiHub::Activity&); // v1.33.4 (M20): one message
    // v1.33.4 (H4): the MIDI jog's smoothing and the speed it drives. The
    // status timer calls it; the selftest calls it too (there is no message
    // loop there).
    void updateMidiScrub();
    // v1.33.4 (H4): the speed the transport runs at when no MIDI jog has it
    // (the Rev toggle's own speed).
    double basePlayRate() const { return revPlayBtn.getToggleState() ? -1.0 : 1.0; }

    // v1.29: the phone/MobMuPlat OSC scrub. The receiver parses the
    // messages and hands the scrub value over; the gesture itself (the
    // preview, the freeze, the timeout) belongs to the app.
    void oscScrubReceived (double normalised) override;
    void handleOscScrub (double normalised);
    void updateExternalScrub (double nowMs);

    void updateMidiLabels();      // v1.23: the learn buttons and the bindings
    void refreshMidiDevices();    // v1.23: rebuild the device list
    void setMaterial(int m);          // v1.8: tab + canvas layer (0 osc, 1 sample, 2 live)
    void syncMaterialTabs();          // tab toggles follow drawMatMode
    void loadSampleIntoSlot(int slotIndex);
    void pushSieve();                 // sieve UI -> state + ScoreEditor
    void applyStepToSelection();      // v1.32: the discrete frequency space
    void applySpaceToSelection();     // v1.33: the arc's frequency space
    void pushSpaceDefs();             // v1.33: the page's four spaces
    void refreshSpaceBox();           // v1.33: the arc's space combo
    void showFreqTableEditor (int space);   // WP1: the drawn conversion table
    void closeFreqTableEditor();
    bool freqTableDestinationIsValid() const;
    void invalidateFreqTableDestination();
    void showAmpTableEditor();              // WP2: the amplitude table bank
    void closeAmpTableEditor();
    void refreshAmpTableBox();
    void applyAmpTableToSelection (int id);
    int  ampTableUseCount (int id) const;
    int  ampTableIndexOfId (int id) const;
    void refreshAmpTableEditor();
    void showGroupPanel();                  // WP3: the arc-group panel
    void showSequencePanel();               // WP4: the performance sequences
    void closeSequencePanel();
    void refreshSequencePanel();
    // --- WP6.4: the mixer ---
    void refreshChannelBox();
    void refreshChannelPanel();
    void showChannelPanel();
    void closeChannelPanel();
    void setChannelOnSelection (int channelId);
    int  channelIndexOfId (int id) const;
    // --- end WP6.4 ---

    int  sequenceIndexOfId (int id) const;
    void startSequenceRecording();
    void stopSequenceRecording();
    void startSequencePlayback();
    void stopSequencePlayback();
    void sequenceRecordTick();
    void toggleSequenceLoop();
    void sequenceAppendRecorderPoint (double t, int page, double pos);
    void closeGroupPanel();
    void refreshGroupPanel();
    void refreshModBox();                    // WP5
    void setModOnSelection (int modId, int target, double depth);
    bool modWouldCycle (int carrierId, int modId) const;
    int  groupIndexOfId (int id) const;
    void pushAmbitus();               // v1.33: the page's ambitus
    void pushWarp();                 // v1.33: the page's acceleration
    void runGenerator(int kind);      // procedural arc generation (nUPIC-style)
    void exportStems();               // one WAV per voice into a folder
    void flash(const juce::String& m); // transient status message (4s)
    void startPlayback(), stopPlayback(bool fromAudio = false);
    void renderWav();
    // v1.33.4 (L15): the save with a file chooser. `onDone` is called with
    // the result - true when the piece really was written. The window uses
    // it: it only closes when the save happened (a cancelled chooser must
    // not throw the work away).
    void saveFile (std::function<void (bool saved)> onDone = {}), loadFile();
    void ensureLiveInputFor(std::function<void(bool)> done);
    void requestLiveInput(std::function<void(bool)> done);
    bool enableDeviceInputs();
    bool tapLiveInput(const juce::AudioSourceChannelInfo& info); // true -> apply monitor mix
    void startCapture();
    void requestCaptureStop(int reason);
    void handoffCapture();  // audio thread -> message thread handoff
    void finalizeCapture(); // message thread: install take into selected slot
    juce::String takeName();

public:
    // v1.33.4 (L15): the save with a file chooser, for the window's
    // unsaved-changes prompt: the app closes only when the piece really was
    // written (a cancelled chooser leaves the window open).
    void savePieceWithDialog (std::function<void (bool saved)> onDone)
    {
        saveFile (std::move (onDone));
    }
    void injectMidiMessage (const juce::MidiMessage&); // v1.25: plugin host MIDI bus
    // v1.33.4 (H4): the MIDI scrub transport (UPIC-28). A CC bound to "Scrub"
    // is a signed jog (the value around the centre 64 sets the speed, up to
    // +/- 4x); a NOTE bound to "Scrub" is an absolute position: the note's
    // number picks a spot on the page and the playhead moves there (the
    // playhead is signed - the note can move it backwards). The jog puts the
    // transport's speed back when it ends, so the next playback is not stuck
    // at the jog's speed, and the host's transport yields while the jog runs
    // (the two must not fight over the playhead).
    //
    // The selftest drives the MIDI handling without a message loop (the
    // status timer never ticks there), so these two hooks are public.
    void pollMidiForTest() { handleMidi(); }
    void updateMidiScrubForTest() { updateMidiScrub(); }
    bool midiScrubRunning() const { return scrubActive; }
    double playRateForTest() const { return playRate.load (std::memory_order_relaxed); }
    // Piece (de)serialization — public so the selftest can round-trip them.
    juce::var pieceToVar() const;
    // v1.33.4 (M28): the piece as a self-contained model, captured under the
    // lock - the worker thread builds the JSON (and the base64 of the
    // samples) from the copy, so the message thread is not held up by it.
    upic::PieceModel capturePieceModel() const;
    // v1.33.4 (M25): the piece is parsed into a temporary model first and
    // replaces the current one only when it really is a piece. Returns false
    // when the var is not a piece - the current piece is then kept, so a
    // broken file cannot wipe the unsaved work.
    bool loadFromVar(const juce::var& v);

    // M4: the Scala tuning import. The file is read through the chooser
    // (a document provider on Android too), and the scale it holds becomes
    // the axis the drawing snaps to. `applyTuning` is public so the
    // selftest can drive it without a chooser.
    void importScalaTuning();
    void applyTuning (const upic::Tuning& t);
    const upic::Tuning& getTuning() const { return tuning; }

    // v1.33.4 (H6): the piece saver. It measures the piece first and refuses
    // (with a message) when it would be bigger than the loader accepts, so
    // the app never writes a piece it cannot reopen. `maxBytes` is the limit
    // to check against - the selftest passes a small one.
    bool savePieceToFile (const juce::File& f,
                          juce::int64 maxBytes = (juce::int64) upic::limits::kMaxPieceBytes);

    // v1.33.4 (M17): the same saver, but the destination can be a
    // document-provider document (Android) - a URL that is not a local file.
    bool savePieceToURL (const juce::URL& url,
                         juce::int64 maxBytes = (juce::int64) upic::limits::kMaxPieceBytes);

    // v1.33.4 (H12): the PM preset file operations, split out of the file
    // dialogs so the selftest can drive them without a chooser.
    // buildPmPresetText() returns the export text of the selected PM arc
    // (empty when no PM arc is selected); applyPmPresetFile() reads a preset
    // file and applies it to the selected PM arcs.
    juce::String buildPmPresetText();
    void applyPmPresetFile (const juce::File& f);

    // --- v1.11 VST3 plugin mode ---------------------------------------------
    bool isPluginMode() const noexcept { return pluginMode_; }
    // Host state: the same JSON text a saved .upic.json piece contains.
    juce::String pieceStateText();
    // Host input-bus channel count (0/1/2); the wrapper calls this from
    // prepareToPlay and from each processBlock.
    void setPluginInputChannelCount(int numChannels);
    // v1.33.4 (M24): how many channels the host wants written. A host layout
    // can have more input channels than output ones (stereo in, mono out),
    // and the extra input channels may be read-only memory - so only the
    // output channels are cleared and written.
    void setPluginOutputChannelCount(int numChannels)
    {
        if (! pluginMode_) return;
        outChannels.store (juce::jlimit (1, 2, numChannels), std::memory_order_relaxed);
    }

private:
    void showAudioSettings();
    void closeAudioSettings();
    void showSettings();
    void closeSettings();
    void startOscReceiver();
    void stopOscReceiver();
    void applyOscSettings();
    void updateOscStatus();
    void rebindOscReceiver();
    void showClearWarning();
    void closeClearWarning();
    void clearCurrentPage();
    // v1.31 (U3): the UPIC's pitch transformations (transpose, invert).
    void transformPage (int op);
    // v1.31 (U4): the digitised wave page (the slot becomes a wavetable).
    bool waveFromSelectedSlot();

    // v1.11 VST3 plugin mode
    bool pluginMode_ = false;
    bool pluginFollowHost = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};