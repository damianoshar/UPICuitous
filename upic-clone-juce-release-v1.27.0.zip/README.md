﻿# UPICuitous - A JUCE-based UPIC clone: the classic oscillator graph becomes sound, and the same score can drive sample and live audio graphs with pitch change. Supports Windows standalone, VST3 plugin, and Android app.

A homage to Iannis Xenakis' UPIC (1977): draw pitch curves on a
time-vs-pitch page, give each arc a single-cycle wavetable and an
amplitude envelope, and hear it. The same score can drive three
materials: oscillators, loaded samples (pitch-shifted) and the live
microphone input (pitch-shifted in realtime).

Ships as a **desktop app**, an **Android tablet app**, and a **VST3
plugin** with the same UI and engine.

## Button pictograms and captions

Most tools now have vector pictograms (Lucide plus custom wave/envelope/tool
shapes). **Every existing button caption remains visibly rendered:** wider
buttons put the icon beside the original text; narrow waveform and envelope
presets put the icon above the original text. On exceptionally small controls,
text has priority and the icon may be omitted. No control names, callbacks,
shortcuts or accessibility labels are changed. The SVGs are included under
`Resources/Icons/`, with attribution and the generator in `Tools/`.

Every numeric slider also wears the same colours now - the treatment the
Master Volume slider always had (unfilled track `#4a4a5c`, filled track
`#5ac8fa`, thumb `#e6f4ff`, value text `#f2f2f7`, value-box outline
`#4a4a5c`). Ranges, values, callbacks, text-box sizes and suffixes are
unchanged - only the colours are.

## Screenshots

![UPICuitous desktop app](docs/screenshots/upicuitous-overview.png)

*Overview: the score page with the Osc material layer selected. Draw
pitch arcs over time; each tab is a separate material on the same page.*

![Sample arcs and pitch modes](docs/screenshots/upicuitous-sample-arcs.png)

*Focused: the Sample tab. Load a slot, draw arcs on the ratio grid, and
choose the pitch mode. Arc x is time; arc y is the playback ratio
(1x = Ref). Granular (stretch) fits the slot to the arc length;
Varispeed and Granular (no stretch) change the slot's playback length
with pitch; Phase vocoder shifts pitch only. The material view shows the
waveform and a time bar; drag the centre line to scrub, and drag the two
yellow edges to trim the material.*

## Builds in this repo

| Build | Where | State |
|---|---|---|
| JUCE C++ (desktop + Android + VST3) | `Source/`, `Plugin/`, `Builds/Android/` | The main build. v0.28.1 |
| Python + tkinter + numpy | `python-upic/` | Prototype, shares `.upic.json`. `python python-upic/upicuitous.py` |
| Single-page WebAudio | `web-upic/` | Prototype, shares `.upic.json`. Open `web-upic/index.html` |

## Quick start

```powershell
# Everything: app (Debug) + selftest + VST3 (Release) + smoke test + pluginval
.\scripts\build.ps1

# Standalone
.\Builds\VisualStudio2026\x64\Debug\App\UPICuitous.exe

# VST3 (built by the script; the install asks for admin rights)
.\scripts\install_plugin.ps1 -Version 0.28.1
```

`scripts/build.ps1 -Version 0.28.1` bumps the version everywhere it is
written - the app, the plugin, the root CMake project, the Android manifest
and the generated exporters - from one number in `UPICuitous.jucer`. Every
build checks that the others still agree with it. `-SkipApp` or `-SkipPlugin`
narrows the run. See `BUILDING.md` in the private `UPICuitous-docs` repository
for the manual CMake commands, the Android project and troubleshooting.

First run of the standalone: press **Audio** and pick the output device.
The microphone is opened on demand (Sample tab -> **Mon** / **Capture**, or
**Play** with live arcs on the page).

## What it does

**One tab strip - Osc | Sample | Live | PM.** Each tab is a material and its
own canvas layer, on the same page and timeline. Switching tabs is
instant and never touches the audio device (v1.17).

**The toolbar** - the settings are laid out in **groups**: transport, pages,
files, tempo, clock, voice, levels, pitch, material, sieve, magnets, page,
tools, scrub and dragging. A group keeps its controls together, but it no
longer needs a row of its own - the next group continues on the same line
when there is room. A group wider than the line wraps inside itself, and
its card follows it line by line, so no control is left on the bare
background. The **level sliders** (intensity, duration, master) are
one group, so they always sit together. The whole window - toolbar,
score, editors and the tab strip - shares one dark surface, so the cards
never sit on black or leave shadow-like patches. On a large screen the long
explanations (the material's hint and the keyboard/shortcut list) move into
their own **sidebar** on the right, where the spare space is; the **Hints**
toggle in the strip above the canvas shows and hides it, and the toolbar
reflows at once with no leftover card fragments. No button cuts its
own text off - every control is measured and gets at least the width its
text needs. The **Capture** button is green, and turns red while it
records; the wavetable's shape buttons wear the colour of the wave they
make (the same palette the arcs use).

**Score page**

- X = time (5-120 s per page), Y = log pitch 20 Hz - 12 kHz.
- Tools: Draw (snap), Line, Sine, Erase, Select/Move, Zone.
- Magnetic sieve zones with their own sieve, time grid and stickiness; global
  sieve (Xenakis `n mod m` remainders), stickiness, time grid, presets.
- **The sieve row** - the sieve on its own, because it only quantises the
  drawing's **pitches**: **Sieve** + **m** + **R** allow only the pitches
  whose MIDI number is `n mod m` in the remainder list. With a hard snap
  (**Stick = 1**) the curve becomes a real **staircase**: the pitch holds
  until it crosses the next allowed step, then jumps. The step corners are
  two points at the same time, so the drawing shows the stairs and the
  sound holds and jumps with them. (The freehand and the Line tool both
  produce this; the time grid can still move the corner in time.) Below 1
  the drawing keeps its intermediate pitches and stays a smooth magnetised
  curve. The allowed pitches are also drawn as faint **guide lines** on the
  page, so switching the box on/off is visible before you draw.
- **Global magnets row** - **Stick** and **T-grid**. **Stick** is the
  global knob: how strongly the drawing is pulled toward whatever magnet
  is active - the sieve (the pitches), a zone's own sieve, and the time
  grid (the times). 1 is a hard snap, 0 leaves the drawing free. It applies
  **outside the zones**: a zone carries its own stick (see below) and only
  follows the global value until you set one. **T-grid** quantises the
  drawing's **times**; its points are pulled toward the grid by the
  stickiness, so the curve takes the grid's shape; Off leaves the times
  free. A sieve zone can set its own time grid, which applies inside the
  zone.
- **Page frequency row** - **Ambitus**, **Accel** and **S1-S4** are the
  page's own settings (see below); the S labels show how many arcs are in
  each space. They are not sieve controls.
- **Tools group** - the procedural generators (see below). The keyboard
  hints live in the sidebar (see above).
- **Sieve zones** - the Zone tool draws a magnetic region: inside it the
  points snap to *that zone's* sieve, time grid and stickiness. A zone can
  be **dragged to a new place** (inside it) or **resized by an edge or a
  corner**; right-click a zone for **Sieve**, **Time grid** and
  **Stickiness** submenus (the tick marks show what the zone uses now) and
  the two delete actions. The zone's label shows its `m`/`R`, grid and
  stick, and its allowed pitches and grid are drawn inside it. Inside a
  zone the zone's sieve wins over the toolbar's global Sieve box.
- Procedural generators: stochastic / convergent arborescence, echelon,
  ordinal spine.
- **A tuning of your own** - the File menu's **Import a Scala tuning...**
  reads a Scala (`.scl`) scale file: the description, the number of notes,
  and the pitches as cents (`100.0`) or as ratios (`9/8`). The scale's first
  note (1/1) is the base and sits on middle C; the scale repeats every
  octave and the steps between two notes are interpolated. The file's
  format is the standard one (the 1/1 may be written out or left implicit,
  a note may carry a name after it, and the last note is the octave), and a
  file that does not make a scale is refused with the reason.
  With a scale loaded, the **drawing snaps to the scale's own degrees**
  instead of to the semitones: the magnet, the pitch guide lines and the
  sieve's `m`/`R` all work on the scale (so a seven-note scale gets its
  octave at `m = 7`). The arcs hold frequencies, not pitches, so a tuning
  does not retune what is already drawn - it changes what the pencil lands
  on. The scale travels with the piece, and **Use 12-tone equal
  temperament** puts the semitones back.
- Multi-select: Ctrl+A, Ctrl+C (count), Ctrl+D, Del, arrow nudge,
  Shift-click cycling, right-click menu.
- Undo and redo: **Ctrl+Z** / **Ctrl+Shift+Z** (or **Ctrl+Y**) - also in the
  File menu, where the step says what it was ("Undo Draw", "Undo Delete the
  arc"). A drag is one step, not one per mouse move, and a click that
  changed nothing is not a step at all. The stack holds 50 steps (the
  oldest go first) and is bounded in memory too: a snapshot keeps the
  pages, not the audio, so the sample material is never copied again and
  again.
- Wheel: pan pitch, Alt+wheel zoom pitch, Ctrl+wheel zoom time,
  Shift+wheel pan time; drag the centre line or the playhead triangle to scrub.
- Touch: 1 finger draws/selects/scrubs, pinch zooms, two-finger drag
  pans, long-press opens the context menu.

**Osc tab** - arcs play drawable 1024-sample wavetables (Sine/Saw/
Square/Triangle/Noise/Reed + Smooth/Normalize) through drawable
envelopes (Flat/Percussive/Swell/Gate/Strings). With an arc selected, a
shape edit forks a private copy when an unselected arc shares the wave,
so it only changes the selection. The envelope is a point
curve: **+** adds a point (tap the curve first to place it, otherwise it
splits the widest gap or the segment after the selected point), **-**
removes the selected point(s), dragging moves it. Ctrl/Cmd/Shift-click
adds points to a group and dragging one moves the whole group.
Double-click adds and right-click deletes as before.

**The wave can be more than a timbre** - the UPIC's central idea: *once
a line or curve has been drawn, nothing is really decided about its
interpretation as a signal*. The Osc tab's material row says **Wave as**:
*Oscillator* (the classic case), *+ Amplitude LFO* (the curve also
shapes the loudness) or *+ Frequency LFO* (the curve also moves the
pitch - a fixed pitch or a glissando). **Rate** is the LFO's speed
(0.05-20 Hz) and **Depth** how deep it goes (1 is an octave of pitch, or
a full swing of the amplitude). They edit the selected arcs, and the
settings travel with the piece.

**Sample tab** - four slots: load wav/flac/ogg/aiff, record from the mic,
In/Mon/Capture, input gain. `Ref` is the material's base pitch; arc pitch
sets the playback ratio. Pitch modes: **Varispeed** (default),
**Granular (stretch)**, **Phase vocoder**, **Granular (no stretch)**. At 1x
(the arc sits on Ref) the pitch is unchanged; draw above or below Ref to
transpose. Varispeed and Granular (no stretch) change the slot's playback
length with pitch; Granular (stretch) time-stretches the slot to the arc
length; Phase vocoder keeps the slot's length and shifts pitch only.
Sample-speed grid labels Ref x 2^k. A loaded file keeps its own sample
rate (up to 192 kHz), so a high-resolution file plays at the right speed
instead of being retuned; a file above that rate is refused with a message
rather than played at the wrong speed, and a file longer than 60 seconds
is cut at 60 seconds (counted at the file's own rate) with a note saying
so.
The **Rev** button plays the selected slot backwards - the material is
mirrored, the pitch stays the same. **Slot -> Wave** turns the selected
slot into a wavetable - the UPIC's digitised wave page, where the take
becomes one loop of the oscillator (the pitch then follows the arc).

**The Ref belongs to the slot, not to the arc.** The material has one
unity point - the pitch it was recorded at - and every arc that plays it
shares it, on every page. The Sample tab's `Ref` slider moves the
material's Ref: the arcs on that slot follow it, the grid moves with it
and a new stroke is born with it. (The Live tab's `Ref` still belongs to
the arcs, as it always did.) A piece written before this carries no Ref
on its slots: the slot then inherits the Ref of the first arc that plays
it, so such a piece sounds exactly as it did - and if an arc carried a
Ref of its own, the material's Ref decides now and the app says so when
the piece is opened.

**The material can be edited.** The material view under the score shows
the loaded material; the two yellow edges are handles - drag them to
**trim** the material (the frames outside the region are not played, and
the region is what the piece keeps). **Norm** sets the material's gain so
its loudest point sits just under full scale, **Fade** fades it in and out
over a tenth of its length (a click-free loop) and **Reset** undoes the
material's edits. The **Level** slider (0 - 2) is the slot's own loudness.
The edits are not a rewrite of the audio: they are parameters, so the
undo stack can step over them and they travel with the piece (and with
the host state in the plugin).

**PM tab** - phase-modulation arcs: Ratio, Index, index envelope,
Feedback and 2/4 operators, with bell / brass / pluck presets. The PM
toolbar values are also the values of the next PM arc drawn, and editing
them with a selection updates the selected PM arcs.

**Live tab** - drawn arcs multiply the microphone pitch in realtime.
Pitch modes: **Granular** (default), **Tape**, **Phase vocoder**, with a
range of 1/16x - 16x (four octaves each way). The grid is the multiply
ratio grid: **1x** is the input as-is, **2x** an octave up. `Ref` is the
1x input pitch and retunes the selected live arcs. **Grain** sets the
granular grain size from 5 to 500 ms (default 40 ms). The **Rev**
button in the material row plays the microphone's last 0.5 / 1 / 2 seconds
**backwards** (the buffer duration is yours to pick). When the global
**Rev** toggle is on, every live arc reads the mirrored input ring
regardless of that arc's Rev box.

**Arcs panel** - the **Arcs** toggle (with the Wave / Env / Hints
toggles) opens a list of the arcs on the right: grouped OSC / SAMPLE /
LIVE / PM. A column header names the fields, and every row shows the
arc's id, its pitch range in **Hz**, its **time** span in seconds, its
**page** and its frequency **space** (S1-S4). Clicking a row selects the
arc on the canvas and switches to its tab; Ctrl/Cmd/Shift-click adds it to
a multi-selection. The sample and the live rows carry a **Rev** box (that
arc's material backwards) and a **mode** dropdown (that arc's pitch-shift
algorithm).

**MIDI in** - the **MIDI + OSC settings** overlay (the toolbar Settings
button or the menu) lists the MIDI inputs (`None` when there is none),
shows the last message (CC or note, value, channel, device) and has a
**Learn** row for the master gain, the draw intensity, the **scrub** and
the **transport**: press Learn, move a control, and the parameter follows
it. The bindings are a
controller map - session state, not part of the piece. The VST3 declares
a MIDI input bus, so the host's notes and CCs reach the app as well.
Every message is queued, so a note and its release both arrive (they used
to collapse into one "newest message"), and the channel is the MIDI
channel index - channel 1 reads as 1 and channel 16 as 16.

**Transport and IO** - Play/Stop with click-free fades, Loop, page
sequencer (SEQ), WAV render, per-voice stems, `.upic.json` save/load
(shared with the Python and web builds). The stems are one WAV per voice -
the wavetable voices, the sample slots and the PM voices (a PM-only page
exports its stems too); the live arcs need the microphone, so they are not
exported and the export says so. The export uses the session's own rate
(the device's in standalone, the host's in a plugin). The long jobs - the
WAV render, the stems, the sample import and the save - run on a worker
thread, so the window stays alive while they work; the status line shows
how far the job is, and **File -> Cancel the job** stops it (the file that
was there before is kept). A file that is not a
piece is
refused with a message and the current piece is kept - a bad file can
never wipe the unsaved work. The app knows when the piece differs from
what was last written: closing the window then asks - **Save** (the piece
is written and the app closes), **Discard** (the changes are thrown away)
or **Cancel** (the app stays open) - so an accidental close cannot throw
the work away. If the app dies anyway (a crash, a killed process), the
work is not lost either: while the piece has unsaved changes the app
keeps a **recovery snapshot** in its own data folder, and the next start
asks whether to open it. The snapshot is a small piece file (the pages)
plus the audio in sidecar files - a sidecar is only written when the
audio really changed, so the snapshots do not carry the material again
and again. Saving the piece or throwing it away removes the snapshot;
the plugin keeps no snapshot (the host holds the piece). The piece
carries everything that
changes the sound - the arc's own pitch algorithm and its reversal, the
sample slot's direction, its Ref, its level and the material's own edits
(the trim, the fades, the normalise gain) and the global pitch modes - so
a reopened piece
(or a reopened DAW session) sounds the same; older pieces without those
fields still load, with the old defaults (a piece from before the
per-slot Ref keeps its sound: the slot inherits the Ref of the first arc
that plays it). The piece format has one set of
limits - 2024 arcs per page (the UPIC's own number), 100 pages, 1000
points per arc, 200 sieve zones, 256 notes in a tuning
- and the editor and the loader share them: the editor refuses what does
not fit (and says so), and a piece that is over a limit is loaded truncated
with a message naming what did not fit, so music is never lost silently.
The ids are checked as well: the arcs, the sieve zones, the wavetables and
the envelopes are keyed by their id, so a piece that carries the same id
twice (or an id that was never meant to be one) is renumbered on the way
in, and the next id is derived from the arcs that are there - a duplicate
id can no longer make the selection and the delete hit the wrong arc.

**The render path** - the audio thread walks the samples of a block in
order, so the arc's segment and the envelope's segment are *followed*
with a cursor instead of being searched for every sample. The pitch
interpolation keeps the segment's endpoints (and their log2), so a
sample costs a lerp instead of a binary search and two logarithms. The
old cap's worst case - 500 arcs sounding at the same time - now costs
7.4 ms per 512-sample block at 48 kHz (69% of the block budget; it was
16.4 ms, 154%), and the points per arc barely matter any more (1000
points per arc cost 2% more, not 60%). The page now holds the UPIC's
2024 arcs; that page with every arc sounding at once costs 26 ms
(2.4x the budget; 28 ms with 1000 points per arc), which is what the
overload guard below is for. The selftest measures the worst case every
run and fails if the render path slows down.
**The overload guard** - the engine measures every block and, when the
load stays over the budget, fades out the quietest sounding arcs (over
5 ms, inside the block, so a dropped arc cannot click) and skips them
once silent; when the load drops, the limit grows again and the arcs fade
back in the same way. The limit is adaptive and per engine (the app and
the plugin turn the guard on in their prepare), the gain is keyed by arc
id in a fixed table so the audio thread never allocates, and an export
never runs the guard: the file is exactly what the score says, however
long it takes.
On Android the file chooser hands back a document-provider URL, not a
path; the app works with that URL, so a piece, a sample or a preset picked
from any provider (Downloads, Drive, a file manager) loads and saves
instead of doing nothing.
The WAV render and the stems cover the whole page: a page with an
acceleration (Accel) needs more audio
than it has score - a 30 s page at Accel 0.9 is 49.07 s of audio - and the
file is that long, so the end of the page is no longer cut off. The export
also uses the session's pitch algorithm and grain sizes, and it streams the
render into the file, so a long page does not need the whole render in
memory. Double-click Stop rewinds to the
start. Clear asks first in an in-app warning and uses a red confirm
button. Dragging the playhead while stopped now plays a short scrub
preview. A Rev toggle runs the score backwards (a mirrored stroke sounds mirrored); a learned MIDI jog CC drives a signed, smoothed playhead (up to +/- 4x) in the app and the plugin.

**The MIDI scrub transport** - the control learned to **Scrub** moves the
signed playhead. A **CC** reads its value as an offset from the centre
(64): above the centre the playhead runs forwards, below it backwards,
and the distance is the speed (up to +/- 4x). A **note** works the same
way with its velocity, and the note's release ends the jog. Backwards is
the signed part: the sample slots are read in reverse and the live input
becomes a reversed delay, so the score sounds mirrored. The jog takes the
transport's speed over while it runs and puts it back when it ends, so the
next playback is normal. In the plugin the jog wins over the host's
transport while it runs - the two must not fight over the playhead (the
status line says `SCRUB` while the jog is running).

**Transforming the page** - the UPIC could transpose, reverse and invert a
composition. The File menu's **Transform the page...** submenu carries the
classical transformation family, applied to the selected arcs if there is
a selection and to every arc of the page otherwise:

- **Transpose** up or down an octave or a semitone.
- **Invert the pitch** - mirrors the drawn contour (a rising line becomes
  a falling one of the same size; the canvas is log-pitch, so this is
  what flipping the drawing upside down does, and inverting twice gives
  the page back).
- **Retrograde** - mirrors it in time, so the contour reads backwards
  inside its own span.
- **Augment / diminish** - stretches or compresses it in time (x2, x0.5):
  the same shape, played slower or faster.

**Page duration** - the page's clock, from **5 ms** to **12 minutes**
(the UPIC's own range: a drawing could sit in micro-time as well as in
macro-time). The Dur slider's travel is skewed so 30 s sits in the
middle, and the value box takes an exact number. The drawing works on
a micro-time page too: the minimum distance between two points of a
stroke scales with the page (15 ms on a long page, a fraction of a
millisecond on a 5 ms one), so a short page keeps the whole curve
instead of collapsing it into a single point.

**The discrete frequency space** - the UPIC's frequency space could be the
continuum, where a diagonal line is a glissando, or *discrete*, with equal
temperaments of 1 to 99 divisions per octave: *"the same diagonal arc
would then sound like discrete steps in a defined temperament"*. The
voice row's **Stepped** box and its **Div/oct** slider do this: the arc's
sounding pitch is moved through the temperament, so a glissando is heard
as a staircase of discrete steps while the line on the canvas stays a
smooth curve. It is not the sieve - the sieve quantises where the drawing
sits and holds the drawn pitch between steps, while this snaps the pitch
that plays under a curve that stays smooth. 12 divisions is the chromatic
scale, 19 and 31 the tempered ones, 7 the diatonic one; the scale is
anchored at middle C. The setting belongs to the selected arc (and to the
next one drawn) and travels with the piece.

**The four frequency spaces** - the UPIC's real-time versions had a
*Frequency Table*: *"a composer could choose to operate within up to four
different simultaneous tables or grids that could be superimposed on each
page. These grids were invisible to the eye, however, and accessed by
assigning one of four tables to whatever arc was being drawn, the same
way as one would assign the waveform or envelope to it."*

So a page carries **four frequency spaces** (the page frequency row's
**S1-S4**) and an arc names the one it is played in (the voice row's
**Space**), the way it names its wave or its envelope. A space is a range
of the frequency axis: the position of the drawing on the page's vertical
axis is mapped into it, so the same curve can be heard in another register
(**An octave up**, **An octave down**) or with its intervals scaled
(**Half the range**, **Double the range**). Two arcs can sit in two
spaces at once, and the drawing itself never moves. The S labels show
how many arcs are in each space - changing a space that holds no arc
changes nothing you can hear until you put one there.

**The page's interval and its acceleration** - *"the scale of the
millimetric surface could be selected, so that the vertical axis could
correspond to any interval"* - the **Ambitus** picks the interval the
page's vertical axis covers: the whole range, the 1990s UPIC's
0.01 Hz - 22 kHz, six octaves, three, one, or a single semitone. The
page is a page for that interval: the drawing lives inside it, and the
stepping, the nudge and the spaces all follow it.

**Accel** is the page's acceleration: *"the expansion and contraction of a
page (with the additional option of acceleration and deceleration)"* -
the page's own time runs at a varying rate. Positive starts slow and
speeds up, negative starts fast and slows down; the page still lasts as
long, the time is redistributed inside it. The WAV render follows the
same sweep, so an export sounds like the session.

**Scrub audition** - with Scrub on, dragging the centre line or the
playhead triangle plays a short preview while the transport is stopped.
The toolbar sets **Scrub len**, **Crossfade**, **Release tail** and
**Hold grain**; **Mute drag** mutes the material while editing, and
**Smooth** sets the drag smoothing. A click without a drag holds the
preview; releasing after a drag does not start playback.

![Scrub audition](docs/screenshots/upicuitous-scrub-audition.png)

*Focused: scrub audition. The scrub row shapes the preview; the material
view time bar follows the playhead while dragging.*

**Phone / MobMuPlat scrub (OSC)** - UPICuitous listens on UDP port 9000 and
also joins MobMuPlat's default multicast output `224.0.0.1:54321`, so the
controller works even when the phone cannot save a custom output IP.
Send a float `/upic/scrub <0..1>` (alias `/upic/scrub/pos`) to move the
playhead: 0 is the page start and 1 is the page end. The value feeds the
same seek and scrub-preview path as a canvas drag. Values keep the
preview alive; 2000 ms after the last message the gesture ends (holding
freezes the preview), and releasing never starts playback. The status line shows `OSC 9000` (plus
`MCAST` when the multicast listener is active). A ready-made MobMuPlat
patch lives in `docs/mobmuplat/`: load `UPICuitous-Scrub.mmp`, then set
MobMuPlat's Network output address to the computer's LAN IP and the output
port to 9000 (or leave the defaults). The slider sends values while it is
dragged. The **MIDI + OSC settings** overlay can change the UDP port,
turn multicast on or off, and change the multicast group and port; press
**Apply** to rebind the receivers. These endpoint changes are session-only.

## VST3 plugin

`Plugin/` builds the same `MainComponent` as a VST3: host audio in/out,
host state save/load, host latency reporting. The Live tab reads the
plugin's input bus (put it on an audio track and the live arcs process
that audio).

The live shifters have an inherent delay - granular 220 ms, tape
40-200 ms, phase vocoder about 21 ms. The host is told the delay only
when every audible arc on the page is delayed (a live-only page); a page
that mixes generator arcs with live arcs reports 0, because the score
must stay sample-accurate. The status line shows the current value
(`LAT 220ms`). The delay follows the arc's own algorithm when it has one
(a vocoder arc on a granular page reports the vocoder's delay), and the
host's input bus is read whole - both channels reach the live arcs and
the microphone recording, even when the host's output is mono.

**The host's clock** - the plugin can follow the DAW's transport instead
of running on its own: **File -> Follow the host transport** (the status
line shows `HOST` when it is on). The host's transport then starts and
stops the app, and the host's position is where the app's playhead is -
the page loops under the host's transport, so the drawing repeats for as
long as the DAW plays. The choice is the user's, because the two clocks
are different things: the app's own clock plays the drawing as it is,
the host's clock keeps it in time with the song. A host that does not
offer a playhead changes nothing - the app keeps its own transport.

## Layout

```
Source/              JUCE app + shared engine/UI
  UpicModel.h        the model umbrella: constants, math, theme, Waveform,
                     Envelope, Arc, FreqSpace, Sieve, Generators, Sample,
                     PickedFile, Ids, Page, Piece (one header per concept)
  Tuning.h           the tuning: the scale's degrees and the Scala (.scl)
                     parser (the step axis the sieve and the magnets work on)
  UpicEngine.h       realtime + offline renderer, sample voices (the
                     declarations; the renderPageBlocks template has to stay)
  UpicEngine.cpp     the engine's implementation
  LivePitch.h        granular / tape / phase-vocoder shifters
  ScoreEditor.h      score canvas, tools, touch, grids (the declarations)
  ScoreEditor.cpp    the score canvas's implementation
  WaveformEditor.h   wavetable drawing
  EnvelopeEditor.h   envelope drawing
  MainComponent.*    tabs, transport, pages, file IO, audio, status
                     (MainComponent.cpp + Controls / Layout / Model /
                     Audio / Input / Midi / Piece / Export / Jobs /
                     Recovery)
  JobRunner.h        the long jobs (the worker thread, the report)
  AndroidBars.h      Android status/nav bar helpers
  Main.cpp           the app entry point
  SelfTest.*         the headless checks (--selftest): the runner, the
                     checks by area (Engine / Audio / Model / Files /
                     Midi / Ui / Snapshot) and the allocation counter
Plugin/              VST3 wrapper (CMake): processor, editor, smoke test
scripts/             build.ps1, install_plugin.ps1, fix_android.ps1,
                     check_juce.ps1, fetch_pluginval.ps1
Builds/Android/      Android Studio project (Gradle + CMake)
Builds/VisualStudio2026/  generated Projucer solution (not committed)
docs/android-build.md  what the .jucer owns and what the script owns
python-upic/         tkinter + numpy prototype
web-upic/            single-file browser sketch
```

The development notes - the backlog, the feature plan, the build guide, the
progress log, the known issues and the per-wave design notes - live in the
private `UPICuitous-docs` repository. They are not part of this release
repository.

## Requirements

- Windows with **Visual Studio 2026** (Desktop development with C++),
  MSBuild and CMake 3.22+.
- **JUCE 8.0.6** in `JUCE/` (the app CMakeLists also fetches it if
  missing; `python Tools/fetch_juce.py` downloads it without git).
- MinGW is not supported by JUCE 8 - use MSVC.
- Android: JDK 17, SDK 35, NDK 28.1.13356709, CMake 3.22.1 (see
  `BUILDING.md` in the private `UPICuitous-docs` repository).

## Tests

`UPICuitous.exe --selftest` runs 730 headless checks (DSP, pitch math,
all seven pitch modes, click guard, JSON round-trip, UI layout sweep,
tab wiring, latency rules, the lock-free model snapshot, the sample
reverse read, the live reverse, the live grain size, the forced live
reverse under the global Rev toggle, the MIDI + OSC settings overlay,
the arc list, the MIDI input, the envelope points, the v1.26
multi-selection / toolbar edits, the v1.27
wavetable fork / Stop rewind / Clear warning checks, the granular-vs-varispeed
regression and the UPIC's transformations (transpose, invert, retrograde,
augment), the discrete frequency space, the four frequency spaces, the
ambitus, the infrasonic-to-ultrasound range, the page's acceleration, the
movable sieve zones, the quantised line, the per-zone stickiness, the
sieve checkbox end-to-end, the zone menu actions, the digitised wave page,
the Scala tuning import (the parser, the scale's degrees and the sieve on
the scale's own axis),
the per-slot Ref and the material's own edits (the Ref that decides the
ratio, the trim, the fades, the normalise gain, the slot's level and the
piece from before M5 that keeps its sound),
the micro-time page, the toolbar's group flow, the hints sidebar, the
button text fitting, the capture button's colours, the wavetable
buttons' colours, the PM preset round trip, the WAV export, the piece
saver, the MIDI device handling, the sound-affecting settings that
travel with a piece, the export of a page with an acceleration, the piece
format's limits at limit minus one, limit and limit plus one, the sample
material's own sample rate, a failed load keeping the composition, the
sample PCM surviving repeated saves, the stems of a PM-only page, the
latency following an arc's own algorithm, and the file a chooser
returns, the MIDI message queue, the MIDI channel labels, the model
snapshot that the status timer publishes, the audio thread's
allocations (the counter itself, the render, the steady state, a reset
and the vocoder's working memory), the long jobs (the worker thread,
the cancel, and the export that writes its file), the ids of a loaded
piece (the duplicate arc ids, the impossible ones, the derived next id
and the material references), the values that cross the thread boundary
(the sample rate and the scrub tail), the unsaved-changes flag, the undo
stack (the step, the restore, the redo, the branch, the drag that is one
step, and the stroke on the canvas), the recovery snapshot (the
snapshot, the sidecar with the audio, the reuse of the unchanged audio,
the read-back and the broken snapshot), the host transport follow (the
choice of the clock, the start, the stop and the position), the drawing
on a micro-time page (the arc, its points and their spread), the MIDI
scrub transport (the note jog, the backwards jog, the speed that goes
back and the host that yields) and the cursor render path (the pitch,
the intensity and the envelope, forwards and backwards), the overload
guard (the fade, the limit, the adaptive ceiling and the silenced arcs) ) and
writes
the log to `%TEMP%\upic_selftest.txt`. The build script also runs the
22-check plugin smoke test and pluginval at strictness 5.

## Xenakis notes

Original UPIC: electromagnetic pen + tablet -> VAX -> DAC. Vertical =
log pitch, horizontal = time; waveform and envelope drawn separately and
assigned to arcs. This clone keeps that triptych: **Page / Wavetable /
Envelope**, and adds samples and live input as further materials.

The UPIC's details here are checked against **"From Xenakis's UPIC to
Graphic Notation Today"** (Hatje Cantz / ZKM, 2024, open access) -
François-Bernard Mâche's "The UPIC Upside Down" and Brigitte Robindoré's
"Beyond the Continuum" - and against the official Xenakis dictionary
entry (Di Scipio, 2023).

Next: see `FUTURE_IDEAS.md` in the private `UPICuitous-docs` repository and
the Kanso board. The signed playhead,
MIDI scrub, live reverse and PM voice shipped in v1.25; the FM8 bridge,
the full FM engine and DAW sync are still flagged as future ideas.

### Vector button and tool images

The default JUCE UI includes 52 embedded, scalable SVG icons (`Resources/Icons/`).
Transport and file/page controls have standard pictograms; the small wave and
envelope preset buttons show the actual preset shapes; the TOOL selector displays
an icon for its currently selected drawing mode. Button callbacks and text remain
unchanged, and the icons are bundled directly into the C++ sources for use in
standalone, VST3, Projucer and Android builds. Attribution and regeneration
instructions are in `Resources/Icons/README.md`.

![The button and tool icons](docs/screenshots/upicuitous-button-icons.png)
